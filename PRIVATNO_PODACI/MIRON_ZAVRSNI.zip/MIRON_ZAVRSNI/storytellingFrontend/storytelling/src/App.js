import './App.css';
import * as React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // import Router

import Login from './components/Login';
import MainPage from './components/MainPage/MainPage';
import CreateGame from './components/CreateGame/CreateGame';
import PlayGame from './components/PlayGame/PlayGame';
import Story from './components/MainPage/Story';
import HorizontalFlow from './components/HorizontalFlow';
import PaginationComponent from './components/Pagination/PaginationComponent';

function App() {
  return (
    <div className="App">
      <Router> {/* Add Router component as a parent */}
        <Routes>    
          <Route path="/login" element={<Login />} exact />
          <Route path="/profile" element={<MainPage />} exact />
          <Route path="/createGame" element={<CreateGame />} exact />
          <Route path="/playGame" element={<PlayGame />} exact />
          <Route path="/story" element={<Story />} exact />
          <Route path="/orderScenes" element={<HorizontalFlow />} exact /> {/* Add this route */}
          <Route path="/paging" element={<PaginationComponent />} exact /> {/* Add this route */}

        </Routes>
      </Router> {/* Close Router component */}
    </div>
  );
}

export default App;
