import React, {useState, memo } from "react";
import { Handle, Position } from "reactflow";
import './Modal.css'
import Modal from './Modal.js';

export default memo(({ data, isConnectable }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
   setIsModalOpen(true);
 };

 const closeModal = () => {
   setIsModalOpen(false);
 };

  return (
<>    
      <Handle
        type="target"
        position={Position.Left}
        style={{ bottom: 10, top: "auto", background: "#555" }}
        className="customHandleStyle"
        onConnect={(params) => console.log("handle onConnect", params)}
        isConnectable={isConnectable}
      />
      <div className="myCustomNode">
        <div>{data.label}</div>
        <button onClick={openModal} className="button-81">Scene details</button>
        <button onClick={() => data.setAsFirst(data.id)} className="button-81">Set as First Node</button>
      </div>

      <Handle
        type="source"
        position={Position.Right}
        id="a"
        style={{ top: 10, background: "#555" }}
        isConnectable={isConnectable}
      />
      
      <Modal isOpen={isModalOpen} closeModal={closeModal}>
        <div className="containerModal">
          <div className="block profile-pic-modal">
            <img src={`data:image/jpeg;base64,${data.image}`} alt="Scene" className="scene-image-modal" />
          </div>
          <div className="block informationModal">
            <h2 style={{ fontFamily: 'Cursive', fontSize: '20px', marginBottom: '8px' }} className="text-white">
              {data.label}
            </h2>
            <p style={{ fontFamily: 'Cursive', fontSize: '16px', lineHeight: '1.5', marginBottom: '12px' }} className="text-white">
              {data.description}
            </p>
          </div>
          <div className="button-container">
            <button className="button-81">Update scene</button>
            <button className="button-81">Delete scene</button>
            <button className="button-81" onClick={closeModal}>Close</button>
          </div>
        </div>
      </Modal>

      <Handle
        type="source"
        position={Position.Right}
        id="b"
        style={{ bottom: 10, top: "auto", background: "#555" }}
        isConnectable={isConnectable}
      />
    
    </>
  );
});
