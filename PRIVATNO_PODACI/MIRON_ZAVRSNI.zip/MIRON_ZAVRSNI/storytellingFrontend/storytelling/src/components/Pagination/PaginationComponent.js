import React, { useState, useEffect } from 'react';
import './PaginationComponent.css'

const PaginationComponent = () => {
  const [scenes, setScenes] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    fetchData();
  }, [currentPage, pageSize]);

  const fetchData = async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/scene/getScenes?page=${currentPage}&pageSize=${pageSize}`
      );
      const responseData = await response.json();
      setScenes(responseData.content);
      setTotalPages(responseData.totalPages);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handlePageSizeChange = (pageSize) => {
    setCurrentPage(1);
    setPageSize(pageSize);
  };

  return (
    <div className="scrollable-container">
      <div className="scenes-container">
        {scenes.map((scene) => (
          <div className="container4" key={scene.id}>
            <div className="scene-container">
              <div className="block profile-pic">
                <img src={`data:image/jpeg;base64,${scene.image}`} alt="Scene" className="scene-image" />
              </div>
              <div className="block information">
                <h2 style={{ fontFamily: 'Cursive', fontSize: '20px', marginBottom: '8px' }} className="text-white">
                  {scene.name}
                </h2>
                <p style={{ fontFamily: 'Cursive', fontSize: '16px', lineHeight: '1.5', marginBottom: '12px', width: '300px', wordWrap: 'break-word' }} className="text-white">
                  {scene.description}
                </p>
              </div>
            </div>

            {scene.idTask !== 0 ? (
              <div className="task-information">
                <p className="text-grey">Task information for this scene</p>
                <p className="text-grey">Question: {scene.task.question}</p>

                {scene.task.questionType === 'text' ? (
                  <p className="text-grey">Answer: {scene.task.answer}</p>
                ) : (
                  <div>
                    <h3 className="task text-grey">Options:</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr' }} className="text-grey">
                      <div style={{ marginRight: '10px' }}>A: {scene.task.optionA}</div>
                      <div style={{ marginLeft: '10px' }}>B: {scene.task.optionB}</div>
                      <div style={{ marginRight: '10px' }}>C: {scene.task.optionC}</div>
                      <div style={{ marginLeft: '10px' }}>D: {scene.task.optionD}</div>
                    </div>
                    <h3 className="task text-grey">
                      <span className="correctAnswer text-grey">Correct Answer: </span>{scene.task.correctAnswer}
                    </h3>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-white">There is no task connected to this scene.</p>
            )}
          </div>
        ))}
      </div>

      <div className="pagination-container">
        <button
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
          className="pagination-button"
        >
          Previous
        </button>
        <span className="pagination-info">{`Page ${currentPage} of ${totalPages}`}</span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => handlePageChange(currentPage + 1)}
          className="pagination-button"
        >
          Next
        </button>
      </div>

      <div>
        <label>Page Size:</label>
        <select
          value={pageSize}
          onChange={(e) => handlePageSizeChange(Number(e.target.value))}
        >
          <option value={3}>3</option>
          <option value={10}>10</option>
          <option value={20}>20</option>
          <option value={50}>50</option>
        </select>
      </div>
    </div>
  );
};

export default PaginationComponent;
