import React from 'react';
import { getBezierPath, getEdgeCenter } from 'react-flow-renderer';

const CustomEdge = ({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
}) => {

  const edgePath = getBezierPath({ sourceX, sourceY, sourcePosition, targetX, targetY, targetPosition });
  const [labelX, labelY] = getEdgeCenter({ sourceX, sourceY, targetX, targetY });

  return (
    <>
      <path id={id} style={{ stroke: '#f00' }} className="react-flow__edge-path" d={edgePath} />
      <div
        style={{
          position: 'absolute',
          transform: `translate(${labelX}px,${labelY}px)`,
          background: '#ffcc00',
          padding: 10,
          borderRadius: 5,
          fontSize: 12,
          fontWeight: 700,
        }}
      >
        blaaaa
      </div>
    </>
  );
};

export default CustomEdge;
