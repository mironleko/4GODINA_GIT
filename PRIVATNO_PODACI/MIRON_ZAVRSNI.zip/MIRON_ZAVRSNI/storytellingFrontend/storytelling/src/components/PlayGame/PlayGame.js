import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MoonLoader } from 'react-spinners';
import './PlayGame.css'

function PlayGame() {
  const [isLoading, setIsLoading] = useState(true);
  const [scene, setScene] = useState(null);
  const [task, setTask] = useState(null);
  const [userAnswer, setUserAnswer] = useState('');
  const [isGameFinished, setIsGameFinished] = useState(false);
  
  const navigate = useNavigate();
  let location = useLocation();
  let story = location.state.story;

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const fetchScenes = async () => {
      const response = await fetch(`story/getFirstScene/${story.id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data);
        setScene(data);
      } else {
        console.error('Failed to fetch scenes');
      }
    };

    fetchScenes();
  }, [story]);

  useEffect(() => {
    const fetchTask = async () => {
      if (scene && scene.idTask > 0) {
        console.log('Fetching scene');
        console.log(scene.idTask);

        const response = await fetch(`/scene/getTaskForScene/${scene.id}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (response.ok) {
          const data = await response.json();
          console.log(data);
          setTask(data);
        } else {
          console.error('Failed to fetch task');
        }
      }else {
        setTask(null); 
      }
    };

    fetchTask();
  }, [scene]);

  document.body.style.backgroundImage = "url('background.jpg')";
  document.body.style.backgroundSize = "100% 100%";

  if (isLoading || !scene) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <MoonLoader color="blue" />
      </div>
    );
  }

  const handleChangeAnswer = (e) => {
    setUserAnswer(e.target.value);
  };

  const handleAnswer = async (answer) => {
    setIsLoading(true);
    if(answer === task.correctAnswer){

      const username = localStorage.getItem('username');  
      const storyName = localStorage.getItem('story'); 
      const sceneId = scene.id; // replace with actual scene id
      const correctAnswer = true; // replace with actual answer status
      
      const response1 = await fetch('/userProgress/addNew', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          storyName: storyName,
          sceneId: sceneId,
          correctAnswer: correctAnswer,
        }),
      });
      
      if (!response1.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      let nextSceneId = scene.correctAnswerSceneId;
      const response = await fetch(`/scene/getNextScene/${nextSceneId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      if (response.ok) {
        if (response.status === 204 || response.headers.get('content-length') === '0') {
          console.log('End of game');
          setIsGameFinished(true);
        } else {
          const data = await response.json();
          console.log(data);
          setScene(data);
        }
      } else {
        console.error('Failed to fetch next scene');
      }
      setIsLoading(false);
    }else{
      const username = localStorage.getItem('username');  
      const storyName = localStorage.getItem('story'); 
      const sceneId = scene.id; 
      const correctAnswer = false;
      
      const response1 = await fetch('/userProgress/addNew', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          storyName: storyName,
          sceneId: sceneId,
          correctAnswer: correctAnswer,
        }),
      });
      
      if (!response1.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      let nextSceneId = scene.wrongAnswerSceneId;
      const response = await fetch(`/scene/getNextScene/${nextSceneId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      if (response.ok) {
        if (response.status === 204 || response.headers.get('content-length') === '0') {
          console.log('End of game');
          setIsGameFinished(true);
        } else {
          const data = await response.json();
          console.log(data);
          setScene(data);
        }
      } else {
        console.error('Failed to fetch next scene');
      }
      setIsLoading(false);
    }
  };

  const goBackToProfile = () => {
    navigate('/profile');
  };

  const handleSubmit = async (e) => {
    setIsLoading(true);
    e.preventDefault();
    const username = localStorage.getItem('username');  
      const storyName = localStorage.getItem('story'); 
      const sceneId = scene.id; // replace with actual scene id
      var correctAnswer = false; // replace with actual answer status
      console.log(userAnswer + "    " + task.answer);
    if(userAnswer === task.answer){
        correctAnswer = true;
    }else{
      correctAnswer = false;
    }

    const response1 = await fetch('/userProgress/addNew', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: username,
        storyName: storyName,
        sceneId: sceneId,
        correctAnswer: correctAnswer,
      }),
    });
    
    if (!response1.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    let nextSceneId = userAnswer === task.answer ? scene.correctAnswerSceneId : scene.wrongAnswerSceneId;
    const response = await fetch(`/scene/getNextScene/${nextSceneId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        console.log('End of game');
        setIsGameFinished(true);
      } else {
        const data = await response.json();
        console.log(data);
        setScene(data);
      }
    } else {
      console.error('Failed to fetch next scene');
    }
    setIsLoading(false);
  };

  if (isGameFinished) {
    return (
      <div>
        <h1>Game Over</h1>
        <button className='button-21' onClick={goBackToProfile}>Back to profile</button>
      </div>
    );
  }

  return (
    <div className="story-page">
      <div className="custom-container" style={task === null ? {display: 'flex', justifyContent: 'center'} : {}}>
        <div className="scene-column">
          <div className="image-container"> 
            <img src={`data:image/jpeg;base64,${scene.image}`} alt="Scene" className='scene-image-play' />
          </div>
          <h2>{scene.name}</h2>
          <p>{scene.description}</p>
          {task === null && (
          <button onClick={goBackToProfile} className='button-15'>Finish Story</button>
        )}
        </div>
        {task && (
          <div className="task-column">
            <h3>Question: {task.question}</h3>
            {task.questionType === 'text' ? (
              <form onSubmit={handleSubmit}>
                <div className="input-button-container"> 
                  <label htmlFor="answer">Answer:</label>
                  <input id="answer" type="text" value={userAnswer} onChange={handleChangeAnswer} />
                  <button type="submit" className="button-15">Submit</button>
                </div>
              </form>
            ) : (
              <div className="task-options-container">
                <button onClick={() => handleAnswer("A")} className='button-15'>A: {task.optionA}</button>
                <button onClick={() => handleAnswer("B")} className='button-15'>B: {task.optionB}</button>
                <button onClick={() => handleAnswer("C")} className='button-15'>C: {task.optionC}</button>
                <button onClick={() => handleAnswer("D")} className='button-15'>D: {task.optionD}</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
  
}

export default PlayGame;
