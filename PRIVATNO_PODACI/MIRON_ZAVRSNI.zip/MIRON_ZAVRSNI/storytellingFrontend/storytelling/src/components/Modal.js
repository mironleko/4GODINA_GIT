import ReactDOM from "react-dom";
import React from "react";
import './Modal.css';

const Modal = ({ children, isOpen, closeModal }) => {
  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <>
      <div className="modal-overlay" onClick={closeModal}></div>
      <div className="modal-content">{children}</div>
    </>,
    document.getElementById('modal-root')
  );
};

export default Modal;