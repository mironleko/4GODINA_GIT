import React, { useState, useEffect, useCallback } from "react";
import ReactFlow, {
  useNodesState,
  useEdgesState,
  addEdge,
  MiniMap,
  Controls
} from "reactflow";
import "reactflow/dist/style.css";
import "./HorizontalFlow.css"
import MyCustomNode from "./MyCustomNode";
import Spinner from 'react-bootstrap/Spinner';
import { useNavigate } from 'react-router-dom';
import { MoonLoader } from "react-spinners";

const connectionLineStyle = { stroke: "#fff"};
const snapGrid = [20, 20];
const nodeTypes = {
  selectorNode: MyCustomNode
};

const defaultViewport = { x: 0, y: 0, zoom: 1.5 };

const HorizontalFlow = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [scenes, setScenes] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [selectedScene, setSelectedScene] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const navigate = useNavigate();


  const handleSceneChange = (e) => {
    setSelectedScene(e.target.value);
  }
  const handleSubmit = (e) => {
   const scene = scenes.find(scene => scene.name === selectedScene);
 
   if (!scene) return;
 
   const newNode = {
     id: `${scene.id}`,
     type: "selectorNode",
     data: { 
      label: scene.name,
      description: scene.description,  // This line is new
      image: scene.image,  // This line is new
    },
     style: { border: "1px solid #777", padding: 10,borderRadius:"5px",backgroundImage:"linear-gradient(1deg, #4F58FD, #149BF3 99%)"},
     position: { x: 200, y: 200 },
   };
 
   setNodes((ns) => ns.concat(newNode));
   setScenes(scenes.filter(sc => sc.name !== selectedScene)); // Filter out the added scene
   setSelectedScene(''); // Reset the selected scene
 }


 const removeNode = async () => {
  setIsLoading(true);
  if (!selectedNode) return;

  
  // Here is the new part:
  // Make an API request to remove the connections related to the selected node

  const response = await fetch("http://localhost:8080/story/removeNode", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({id:selectedNode}) // send the selected node id as NodeDTO
  });
  
  if (!response.ok) {
    alert('Error removing connections: ' + response.status);
    return;
  }

  // Then we can remove the edges related to the node in the UI
  fetchScenes();  
  setSelectedNode(null); // Clear selection
  setTimeout(() => {
    setIsLoading(false);
  }, 1000);
};

  const onNodeDragStop = (event, node) => {
   setSelectedNode(node.id);
   console.log(node.id);
 }
 const setStoryForTelling = async ()=>{
  var story = localStorage.getItem('story');
  const response = await fetch("story/setStoryReady", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({title:story}) 
});
if (!response.ok) {
  alert('Error: ' + response.status);
  return;
}

alert('Story is ready');
navigate('/profile')

 }
 const goBackToCreateGame = () => {
    navigate('/createGame');
    setIsLoading(false);
};
 const saveStory = async () => {
   var story = {nodes,edges};
   const response = await fetch("http://localhost:8080/story/saveStory", {
       method: "POST",
       headers: {
           "Content-Type": "application/json"
       },
       body: JSON.stringify(story)
   });

   if (!response.ok) {
       alert('Error: ' + response.status);
       return;
   }

   alert('Story saved successfully');
};
const fetchScenes = async () => {
  const storyName = localStorage.getItem('story');
  const findScenes = await fetch(`scene/getScenes/${storyName}`, {
      method: "GET",
      headers: {
          "Content-Type": "application/json"
      }
  })
  const data = await findScenes.json();
  const answerSceneIds = data.reduce((acc, scene) => {
    if (scene.correctAnswerSceneId > 0) acc.push(scene.correctAnswerSceneId);
    if (scene.wrongAnswerSceneId > 0) acc.push(scene.wrongAnswerSceneId);
    return acc;
  }, []);
  
const nodesFromScenes = data
.filter(scene => 
  answerSceneIds.includes(scene.id) ||
  scene.correctAnswerSceneId > 0 ||
  scene.wrongAnswerSceneId > 0
)
.map(scene => ({
  id: `${scene.id}`,
  type: "selectorNode",
  data: {
    id: `${scene.id}`, 
    label: scene.name,
    description: scene.description,  
    image: scene.image,
    setAsFirst: setFirstNode,  
  },
  style: { border: "1px solid #777", padding: 10,borderRadius:"5px",backgroundImage:"linear-gradient(1deg, #4F58FD, #149BF3 99%)"},
  position: { x: scene.xCoordinate, y: scene.yCoordinate },
}));


  const edgesFromScenes = data.reduce((acc, scene) => {
    if (scene.correctAnswerSceneId > 0) {
      acc.push({
        id: `edge-${scene.id}-${scene.correctAnswerSceneId}`,
        source: `${scene.id}`,
        target: `${scene.correctAnswerSceneId}`,
        type: 'smoothstep',
        animated: false,
        style: { stroke: "#black", color:'#blacks'},
        label: 'Correct',
        sourceHandle: 'a', // identifier for top handle
      });
    }

    if (scene.wrongAnswerSceneId > 0) {
      acc.push({
        id: `edge-${scene.id}-${scene.wrongAnswerSceneId}`,
        source: `${scene.id}`,
        target: `${scene.wrongAnswerSceneId}`,
        type: 'smoothstep',
        animated: false,
        style: { stroke: "#black", color:'#blacks' },
        label: 'Wrong',
        sourceHandle: 'b', 
      });
    }

    return acc;
  }, []);

  setNodes(nodesFromScenes);
  setEdges(edgesFromScenes);


  setScenes(data);
  setIsLoading(false);

  console.log(data)
}

useEffect(() => {

  fetchScenes();

}, []); 

  const onConnect = useCallback(
   (params) =>
     setEdges((eds) =>
       addEdge({ ...params, animated: false, style: { stroke: "#black", color:'#blacks' }, label: params.sourceHandle === 'a' ? 'Correct' : 'Wrong' }, eds)
     ),
   []
 );
 const setFirstNode = async (nodeId) => {
  console.log(nodeId);
  // Now also update the backend
  const response = await fetch("story/setFirstNode", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({id: nodeId})  // Send the id to the backend
  });

  if (!response.ok) {
    alert('Error setting first node: ' + response.status);
    return;
  }
  
  // You could do something with the response here if needed
}

  const miniMapStyles = {
    position: 'absolute',
    bottom: '185px', 
    right: '10px', 
    border: '1px solid #888',
    background: '#f9f9f9',
    borderRadius: '4px',
    opacity: 0.8,
  };
 
  return (
    <div style={{ height: '100vh', width: '100vw' }}>
      {isLoading ? (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <MoonLoader color="blue" />
        </div>
      ) : (
        <>  
          <div>
            <div>
              <label htmlFor="language" className="bojaFonta">Select scene:</label>
            </div>
            <select name="language" id="language" value={selectedScene} onChange={handleSceneChange} className="dropdown">
  <option value="">-- Select --</option>
  {scenes
    .filter(scene => !nodes.find(node => node.id === `${scene.id}`))
    .map((scene, index) => (
      <option key={index} value={scene.name}>{scene.name}</option>
    ))}
</select>

            <div>
              <button onClick={handleSubmit} className="button-21">Submit</button>
            </div>
          </div>
  
          {/* This div wraps all the buttons and sets them to display in a row */}
          <div style={{ display: 'flex', justifyContent: 'center'}}>  
  <button style={{ margin: '0 10px' }} onClick={removeNode} className="button-21">Remove Node</button>
  <button style={{ margin: '0 10px' }} onClick={saveStory} className="button-21">Save Story</button>
  <button style={{ margin: '0 10px' }} onClick={setStoryForTelling} className="button-21">Set story for telling</button>
  <button style={{ margin: '0 10px' }} onClick={goBackToCreateGame} className="button-21">Back</button>
</div>
  
          <ReactFlow
  onNodeDragStop={onNodeDragStop}
  nodes={nodes}
  edges={edges}
  onNodesChange={onNodesChange}
  onEdgesChange={onEdgesChange}
  onConnect={onConnect}
  style={{ background: "white", marginTop: '20px',border:"1px solid #888" }} // Add a top margin here
  nodeTypes={nodeTypes}
  connectionLineStyle={connectionLineStyle}
  snapToGrid={true}
  snapGrid={snapGrid}
  defaultViewport={defaultViewport}
  fitView
  attributionPosition="bottom-left"
>
            <div>
              <MiniMap
                nodeStrokeColor={(n) => {
                  if (n.type === "output") return "#ff0072";
                }}
                nodeColor={(n) => {
                  return "black";
                }}
  
                style={miniMapStyles}
  
              />
              </div>
            <Controls />
          </ReactFlow>
        </>
      )}
    </div>
  );
  
  
};

export default HorizontalFlow;
