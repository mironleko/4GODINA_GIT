      import React, { useState,useEffect } from "react";
      import { useNavigate } from 'react-router-dom';

      import './CreateGame.css';
    import { Divider } from "@mui/joy";
    import { MoonLoader } from "react-spinners";

      const CreateGame = () => {
        document.body.style.backgroundImage = "url('background.jpg')";
        document.body.style.backgroundSize = "100% 100%";
        const [name, setName] = useState('');
        const [description, setDescription] = useState('');
        const [selectedImage, setSelectedImage] = useState('');
        const [question, setQuestion] = useState('');
        const [answer, setAnswer] = useState('');
        const [showImage, setShowImage] = useState('');
        const [scenes,setScenes] = useState([]);
        const [tasks,setTasks] = useState([]);
        const [updateScene, setUpdateScene] = useState(null);
        const  [nema,setNema] =  useState('');
        const [selectedTask, setSelectedTask] = useState(null);
        const [isLoading, setIsLoading] = useState(true); // Initialize loading state
        const [tasksWithoutScene,setTasksWithoutScene] = useState([]);
        const [questionType, setQuestionType] = useState('text');
        const [optionA, setOptionA] = useState('');
        const [optionB, setOptionB] = useState('');
        const [optionC, setOptionC] = useState('');
    const [optionD, setOptionD] = useState('');
    const [correctAnswer, setCorrectAnswer] = useState('');

        const navigate = useNavigate();

     
        function toggle3() {
          var blur = document.getElementById('blur');
          blur.classList.toggle('active');
          var popup = document.getElementById('popup3');
          popup.classList.toggle('active');
        }
        
        const saveSceneAndToggle3 = (id)  =>{
          toggle3();
          localStorage.setItem('sceneId', id);
        }

        const handleSelectTask = (task) => {
          setSelectedTask(task);
          toggle3();
          try {
            fetch("scene/addTask", {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body:JSON.stringify({id:task.id,sceneId:localStorage.getItem('sceneId')}),
            }).then((res) => {
              if (res.status !== 200) {
                console.log(res.statusText);
              } else {
                fetchTasks(); // Refresh the tasks list
              }
            })
          } catch (error) {
            console.log(error);
          }
          
        }

        function toggle() {
          var blur = document.getElementById('blur');
          blur.classList.toggle('active');
          var popup = document.getElementById('popup');
          popup.classList.toggle('active');
          var blur2 = document.getElementById('blur2');
          blur2.classList.toggle('active');

        }
        function toggle2() {
          var blur = document.getElementById('blur');
          blur.classList.toggle('active');
          var blur2 = document.getElementById('blur2');
          blur2.classList.toggle('active');
          var popup = document.getElementById('popup2');
          popup.classList.toggle('active');
        }
        const handleImageChange = (e) => {
          setShowImage(URL.createObjectURL(e.target.files[0]));
          setSelectedImage(e.target.files[0]);
          setNema('ima');
        }

        const handleDeleteTask = (idTask) => {
          console.log(idTask);
          try {
            fetch("task/deleteTask", {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({id: idTask})
            }).then((res) => {
              if (res.status !== 200) {
                console.log('Something went wrong');
                console.log(res.statusText);
              } else {
                console.log("Task deleted successfully")
                fetchTasks(); // Refresh the tasks list
              }
            })
          } catch (error) {
            console.log(error);
          }
        }

        const handleDeleteScene = (idTask) => {
          try {
            fetch("scene/deleteScene", {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({id: idTask})
            }).then((res) => {
              if (res.status !== 200) {
                console.log('Something went wrong');
                console.log(res.statusText);
              } else {
                console.log("Scene deleted successfully")
                fetchScenes(); // Refresh the scenes list
              }
            })
          } catch (error) {
            console.log(error);
          }
        }
        const handleUpdateScene = (scene) => {
          setName(scene.name);
          setDescription(scene.description);
          setSelectedImage(scene.image);
          console.log(scene.image);
          setShowImage(`data:image/jpeg;base64,${scene.image}`);
          setUpdateScene(scene);
          toggle();
        };
        const changeVariablesToDefault =()=>{
          setName('');
          setDescription('');
          setSelectedImage(null);
          setShowImage(null);
        }
        const handleBackClick = (scene) => {
          setName('');
          setDescription('');
          setSelectedImage(null);
          setShowImage(null);
          setUpdateScene(null);
          toggle();
        };
        const goToHorizontalFlow = () => {
          navigate('/orderScenes');
        };
        const handleClickCreate = (e) => {
          toggle();
          e.preventDefault();
          var formData = new FormData();

          if(updateScene){
            formData.append('id',updateScene.id);
            formData.append('storyName', updateScene.storyName);
            formData.append('name',name);
            formData.append('description', description);
            if(nema === 'ima'){
              formData.append('selectedImage',selectedImage);
          } else {
              // Create an empty blob and append it as 'selectedImage'
              const emptyBlob = new Blob([""], { type: "image/jpeg" });
              formData.append('selectedImage',emptyBlob, 'empty.jpg');
          }
            for (var pair of formData.entries()) {
              console.log(pair[0]+ ', '+ pair[1]); 
          }            
          
          try {
              fetch("/scene/updateScene", {
                method: "POST",
                body: formData
              }).then((res) => {
                if (res.status !== 200) {
                  console.log('wrong');
                  console.log(res.statusText);
                } else {
                  console.log("you updated scene")
                  changeVariablesToDefault();
                  fetchScenes();
                }
              })
            } catch (error) {
              console.log(error.body);
            }

          }else{
          var storyName = localStorage.getItem('story');
          formData.append('storyName', storyName);
          formData.append('name', name);
          formData.append('description', description);
          formData.append('selectedImage', selectedImage);
          try {
            fetch("/scene/createScene", {
              method: "POST",
              body: formData
            }).then((res) => {
              if (res.status !== 200) {
                console.log('wrong');
                console.log(res.statusText);
              } else {
                console.log("you created new scene")
                changeVariablesToDefault()
              
                // window.location.reload();
              }
            })
          } catch (error) {
            console.log(error.body);
          }
        }
        }
        const handleClickCreateTask = (e) => {
          toggle2();
          e.preventDefault();
          let taskData;
          if(questionType === 'text'){
          const task = {question, answer}
          try {
            fetch("task/createTask", {
              method: "POST",
              body: JSON.stringify(task),
              headers: {
                "Content-Type": "application/json"
              }
            }).then((res) => {
              if (res.status !== 200) {
                console.log('wrong');
                console.log(res.statusText);
              } else {
                console.log("you created new task")
              }
            })
          } catch (error) {
            console.log(error.body);
          }

          }else if (questionType === 'multipleChoice'){
            const options = {
              A: optionA,
              B: optionB,
              C: optionC,
              D: optionD,
            };
        
            taskData = { question, options, correctAnswer};
            try {
              fetch("task/createMultipleChoiceTask", {
                method: "POST",
                body: JSON.stringify(taskData),
                headers: {
                  "Content-Type": "application/json"
                }
              }).then((res) => {
                if (res.status !== 200) {
                  console.log('wrong');
                  console.log(res.statusText);
                } else {
                  console.log("you created new task")
                }
              })
            } catch (error) {
              console.log(error.body);
            }
          }
        }
        const handleBackClick2 = () =>{
          toggle2();
          setAnswer('');
          setQuestion('');
          setOptionA('');
          setOptionB('');
          setOptionC('');
          setOptionD('');
          setCorrectAnswer('');

        }
        const fetchScenes = async () => {
          const storyName = localStorage.getItem('story');
          const findScenes = await fetch(`scene/getScenes/${storyName}`, {
              method: "GET",
              headers: {
                  "Content-Type": "application/json"
              }
          })
          const data = await findScenes.json();
          console.log(JSON.stringify(data) + "fqw");
          setScenes(data);

          setIsLoading(false);

      }
      const goToProfile = ()  =>{
        navigate('/profile');
      }
        const fetchTasks = async () => {
          const findTasks = await fetch("task/getTasks", {
            method: "GET",
            headers: {
              "Content-Type": "application/json"
            }
          })
          const data = await findTasks.json();
          console.log(data);
          setTasks(data);
          setIsLoading(false);

        }
        const fetchTasksWithoutScene = async () => {
          const findTasks = await fetch("task/getTasksWithoutScene", {
            method: "GET",
            headers: {
              "Content-Type": "application/json"
            }
          })
          const data = await findTasks.json()
          console.log("fawf")
          console.log(data);
          setTasksWithoutScene(data);

        }
        useEffect(() => {
          fetchScenes();
        }, [scenes]); 
        
        useEffect(() => {
          fetchTasks();
        }, [tasks]); 
        
        useEffect(() => {
          fetchTasksWithoutScene();
        }, [tasksWithoutScene]); 
        

        return (
          <div style={{ height: '100vh', width: '100vw' }}>
    {isLoading ? (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <MoonLoader color="blue" />
      </div>
    ) : (
          <div>
            <div id="blur" className="boxGroup">
              <button onClick={toggle} className="button-21">New Scene</button>
              <button onClick={toggle2} className="button-21">New Task</button>
              <button onClick={goToHorizontalFlow} className="button-21">Order scenes</button>
              <button onClick={goToProfile} className="button-21">Back to profile</button>

              <div id="blur2" className="container2">
                  <div className="left-container2">
                  <h2 style={{ fontFamily: 'Cursive', fontSize: '20px', marginBottom: '8px' }}className="title-text">
                  Scenes
                </h2>              
                {scenes.map((scene) => (
  <div className="container4" key={scene.id}>
    <div className="scene-container">
      <div className="block profile-pic">
        <img src={`data:image/jpeg;base64,${scene.image}`} alt="Scene" className="scene-image" />
      </div>
      <div className="block information">
    <h2 style={{ fontFamily: 'Cursive', fontSize: '20px', marginBottom: '8px' }}className="text-white">
      {scene.name}
    </h2>
    <p style={{ fontFamily: 'Cursive', fontSize: '16px', lineHeight: '1.5', marginBottom: '12px', width: '300px', wordWrap: 'break-word' }}className="text-white">
      {scene.description}
    </p>
    </div>
      <div className="button-container2">
        <button className="button-81" onClick={()=>handleUpdateScene(scene)}>Update scene</button>
        <button className="button-81" onClick={() => handleDeleteScene(scene.id)}>Delete scene</button>
        <button onClick={()=>saveSceneAndToggle3(scene.id)} className="button-81">Select Task</button>
      </div>
    </div>

    {scene.task ? (
  <div className="task-information">
    <p className="text-grey">Task information for this scene</p>
    <p className="text-grey">Question: {scene.task.question}</p>

    {scene.task.questionType === 'text' ? (
      <p className="text-grey">Answer: {scene.task.answer}</p>
    ) : (
      <div>
  <h3 className="task text-grey">Options:</h3>
  <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr'}}  className="text-grey">
    <div style={{marginRight: '10px'}}>A: {scene.task.optionA}</div>
    <div style={{marginLeft: '10px'}}>B: {scene.task.optionB}</div>
    <div style={{marginRight: '10px'}}>C: {scene.task.optionC}</div>
    <div style={{marginLeft: '10px'}}>D: {scene.task.optionD}</div>
  </div>
  <h3 className="task text-grey">
    <span className="correctAnswer text-grey">Correct Answer: </span>{scene.task.correctAnswer}
  </h3>
</div>
    )}
  </div>
) : (
  <p className="text-white">There is no task connected to this scene.</p>
)}

      </div>
    ))}
                  </div>
                <div className="right-container2">
                <h2 style={{ fontFamily: 'Cursive', fontSize: '20px', marginBottom: '8px', }}className="title-text">
              Tasks
            </h2>
            {tasks.map((task, index) => (
  <div className="container4 task" key={task.id}>
    <div className="block information">
      <h3 className="task text-white">
        <span className="task-number text-white">{index + 1}. </span> 
        <span className="question text-white">Question: </span>{task.question}
      </h3>

      {task.questionType === 'text' ? (
        <h3 className="task text-white">
          <span className="answer text-white">Answer: </span>{task.answer}
        </h3>
      ) : (
        <div>
  <h3 className="task text-white">Options:</h3>
  <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr'}}  className="text-white">
    <div style={{marginRight: '10px'}}>A: {task.optionA}</div>
    <div style={{marginLeft: '10px'}}>B: {task.optionB}</div>
    <div style={{marginRight: '10px'}}>C: {task.optionC}</div>
    <div style={{marginLeft: '10px'}}>D: {task.optionD}</div>
  </div>
  <h3 className="task text-white">
    <span className="correctAnswer text-white">Correct Answer: </span>{task.correctAnswer}
  </h3>
</div>

      )}

    </div>
    <div className="button-container">
      <button className="button-81">Update task</button>
      <button onClick={() => {
        handleDeleteTask(task.id)}} className="button-81">Delete task</button>
    </div>   
  </div>
))}

                </div>
              </div>

            </div>

            <div id="popup">
            <h2 className = "title-text">{updateScene ? 'Update Scene' : 'New Scene'}</h2>
              <form className="formaGroupCreate" id="joinGroupForm" method="POST" action="">
                <div className="containerTextGroup">
                  <div className='box1'>
                    <label htmlFor="name" className='bojaFonta'>Title:</label>
                    <div>
                    <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} />
                    </div>
                    <label htmlFor="description" className='bojaFonta'>Description:</label>
                    <textarea id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} className="new-description"></textarea>
                    <div className="image-container">
  {showImage && <img src={showImage} alt="selected" className="selected-image" />}
</div>
<label htmlFor="image" className='button-21'>
  {showImage ? 'Change Image' : 'Choose Image'}
  <input 
    style={{ display: 'none' }} 
    type="file" 
    id="image" 
    name="image" 
    accept="image/*" 
    onChange={handleImageChange} 
  />
</label>
                    <button onClick={handleClickCreate} type="submit" className="button-21">{updateScene ? 'Update' : 'Create'}</button>
                  </div>
                </div>
              </form>
              <button onClick={handleBackClick} className="button-21">Back</button>
            </div>
            <div className='parentContainer'>

            <div id="popup2">

    <label htmlFor="questionType" className='bojaFonta'>Question Type:</label>
    <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
  <div style={{width: '200px', height: '40px', borderRadius: '5px', overflow: 'hidden', border: '1px solid #000'}}>
      <select 
        id="questionType" 
        value={questionType} 
        onChange={(e) => setQuestionType(e.target.value)}
        style={{width: '100%', height: '100%', border: 'none', outline: 'none', padding: '0 10px', fontSize: '16px', backgroundColor: '#fff'}}
      >
        <option value="text">Text</option>
        <option value="multipleChoice">Multiple Choice</option>
      </select>
  </div>
</div>


    <h2 className="new-task">New Task</h2>
    <form className="formaGroupCreate" id="joinGroupForm" method="POST" action="">
      <div className="containerTextGroup">
        <div className='box1'>
          <label htmlFor="question" className='bojaFonta'>Question:</label>
          <div>
          <textarea 
    id="question" 
    name="question" 
    value={question} 
    onChange={(e) => setQuestion(e.target.value)} 
    rows="3" 
    cols="30" 
  />          </div>

          {questionType === 'text' && (
            <>
              <label htmlFor="answer" className='bojaFonta'>Answer:</label>
              <div>
              <textarea 
    id="answer" 
    name="answer" 
    value={answer} 
    onChange={(e) => setAnswer(e.target.value)} 
    rows="3" 
    cols="30" 
  />         </div>
            </>
          )}

          {questionType === 'multipleChoice' && (
            <>
              <label htmlFor="optionA" className='bojaFonta'>Option A:</label>
<div>
  <textarea id="optionA" name="optionA" value={optionA} onChange={(e) => setOptionA(e.target.value)} rows="1" cols="30"/>
</div>

<label htmlFor="optionB" className='bojaFonta'>Option B:</label>
<div>
  <textarea id="optionB" name="optionB" value={optionB} onChange={(e) => setOptionB(e.target.value)} rows="1" cols="30"/>
</div>

<label htmlFor="optionC" className='bojaFonta'>Option C:</label>
<div>
  <textarea id="optionC" name="optionC" value={optionC} onChange={(e) => setOptionC(e.target.value)} rows="1" cols="30"/>
</div>

<label htmlFor="optionD" className='bojaFonta'>Option D:</label>
<div>
  <textarea id="optionD" name="optionD" value={optionD} onChange={(e) => setOptionD(e.target.value)} rows="1" cols="30"/>
</div>


              <label htmlFor="correctAnswer" className='bojaFonta'>Correct Answer:</label>
              <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
  <div style={{width: '200px', height: '40px', borderRadius: '5px', overflow: 'hidden', border: '1px solid #000'}}>
    <select 
      id="correctAnswer" 
      value={correctAnswer} 
      onChange={(e) => setCorrectAnswer(e.target.value)}
      style={{width: '100%', height: '100%', border: 'none', outline: 'none', padding: '0 10px', fontSize: '16px', backgroundColor: '#fff'}}
    >
      <option value="">Select the correct answer</option>
      <option value="A">A</option>
      <option value="B">B</option>
      <option value="C">C</option>
      <option value="D">D</option>
    </select>
  </div>
</div>
            </>
          )}
        </div>

        <div className="button-create">
          <button onClick={handleClickCreateTask} type="submit" className="button-21">Create</button>
        </div>
      </div>
    </form>
    <button onClick={handleBackClick2} className="button-21">Back</button>
  </div>   
  </div>  
            <div id="popup3">
        <h2>Select a Task</h2>
        {tasksWithoutScene.map((task, index) => (
  <div key={index} >
    <h3>Question: {task.question}</h3>

    {task.questionType === 'text' ? (
      <h3>Answer: {task.answer}</h3>
    ) : (
      <div style={{border: 'none'}}>
        <h3>
          Options: 
          <div style={{border: 'none'}}>A: {task.optionA}</div>
          <div style={{border: 'none'}}>B: {task.optionB}</div>
          <div style={{border: 'none'}}>C: {task.optionC}</div>
          <div style={{border: 'none'}}>D: {task.optionD}</div>
        </h3>
        <h3 style={{border: 'none'}}>Correct Answer: {task.correctAnswer}</h3>
      </div>
    )}

    <button onClick={() => handleSelectTask(task)} className="button-21-small">Select this Task</button>
  </div>
))}
<button onClick={toggle3} className="button-21">Back</button>
</div>
</div>
)}
</div>
        );
      };

      export default CreateGame;
