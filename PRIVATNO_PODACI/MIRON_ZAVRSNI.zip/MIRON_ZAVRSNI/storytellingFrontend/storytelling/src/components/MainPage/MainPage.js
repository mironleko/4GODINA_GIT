import React, { useState,useEffect } from "react";
import './MainPage.css';

import { useNavigate} from 'react-router-dom';
import { MoonLoader } from "react-spinners";
import { FaStar } from 'react-icons/fa';

const MainPage = () => {
  document.body.style.backgroundImage = "url('background.jpg')";
  document.body.style.backgroundSize = "100% 100%";

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [user,setUser] = useState('');
  const [stories, setStories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userProgresses, setUserProgresses] = useState([]);

 
  const fetchStories = async () => {
    const findStories = await fetch("story/getStories", {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    })
    const data = await findStories.json();
    console.log(data);
    setStories(data);
    setIsLoading(false);
  }
  const fetchUserProgresses = async () => {
    const username = localStorage.getItem('username');
    const response = await fetch(`userProgress/getProgress?username=${username}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    });
    const data = await response.json();
    setUserProgresses(data);
}
  async function getResponse() {
    const username = localStorage.getItem("username");
    const responseUser = await fetch(`user/getData?username=${username}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    });
    const data = await responseUser.json();
    setUser(data);
    setIsLoading(false);

  }
  useEffect(() => {
    fetchUserProgresses();
}, []);
  useEffect(() => {
		getResponse();
		if (localStorage.getItem('token') === null) {
			navigate("/login");
		}
    fetchStories();

	}, [],stories);


  const navigate = useNavigate();
  function toggle() {
    var blur = document.getElementById('blur');
    blur.classList.toggle('active');
    var popup = document.getElementById('popup');
    popup.classList.toggle('active');
  }
  const updateTask = (story) => {
    localStorage.setItem('story', story.name);
    navigate('/createGame');  
  }

  const handleClick = (buttonType) => {
    if (buttonType === "play") {
      console.log("Play button clicked");
    } else if (buttonType === "create") {
      console.log("Create button clicked");
    }
  }


  const handleCreateStory = (e) => {
    toggle();
    e.preventDefault();
    var username = localStorage.getItem("username");
    const story = {title,username,description};
      fetch("story/createStory", {
        method: "POST",
        body: JSON.stringify(story),
        headers: {
          "Content-Type": "application/json"
        }
      }).then((res) => {
        if (res.status !== 200) {
          console.log('wrong');
          console.log(res.statusText);
        } else {
          console.log("you created new story");
          localStorage.setItem('story', title);
          navigate('/createGame')
        }
      })
    
  }

  const calculateStars = (userProgress) => {
    const totalTasks = userProgress.length;
    const correctAnswers = userProgress.filter(progress => progress.correct).length;
    const completionPercentage = (correctAnswers / totalTasks) * 100;
  
    let stars = 0;
    let text = '';
    console.log(completionPercentage);
    if (completionPercentage >= 90) {
      stars = 3;
      text = 'Great story';   
    } else if (completionPercentage >= 65) {
      stars = 2;
      text = 'Good story';
    } else if(completionPercentage >= 30){
      stars = 1;
      text = 'Below average story';
    }else {
      stars = 0;
      text = 'Incomplete story';
    }
  
    return { stars, text };
  };
  
  return (
    <div className="main-container">
       {isLoading ? (
      <MoonLoader size={50} color={"#123abc"} loading={isLoading} />
    ) : (
     <div className="content">
    <div className="profile-container">
      <div className="profile-card">
        <h1 className="profile-title">Profile Page</h1>
        <div className="profile-info">
          <p><strong>Username:</strong> {user.username}</p>
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>Surname:</strong> {user.lastname}</p>
          <p><strong>Email:</strong> {user.email}</p>
        </div>
        <div id="blur2">
        <button onClick={toggle} className="button-21">Stvori priču</button>
        </div>
        <div id="popup">
      <h2 className="title-text">New Story</h2>
        <form className="formaGroupCreate" id="joinGroupForm" method="POST" action="">
          <div className="containerTextGroup">
            <div className='box1'>
              <label htmlFor="name" className='bojaFonta'>Title:</label>
              <div>
                <input type="text" id="title" name="title" value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <label htmlFor="description" className='bojaFonta'>Description:</label>
              <textarea id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} cols="30" rows="6"></textarea>
              <div></div><button type="submit" className="button-21" onClick={handleCreateStory}>Create</button>
            </div>
          </div>
        </form>
        <button onClick={toggle} className="button-21">Back</button>
      </div>
      </div>
      </div>

      <div id="blur" className="story-container">
      {stories.map((story, index) => {
            const userProgressExists = userProgresses.filter(
              progress => progress.story.id === story.id
            );
            if (!story.ready && story.author.username !== localStorage.getItem('username')) {
              return null;
            }
            return (
              <div className="story-card" key={index}>
                <div className="story-title">
                  <h2>{story.name}</h2>
                </div>
                <div className="story-description">
                  <p>{story.description}</p>
                </div>
                <div className="story-actions">
                  {(story.ready  && story.author.username !== localStorage.getItem('username')) ? (
                    userProgressExists.length > 0 ? (
                      <div>
                      <div className="stars">
      {Array.from({ length: calculateStars(userProgressExists).stars }).map((_, index) => (
        <FaStar key={index} className="star-icon" />
      ))}
        
    </div>
    <div className="stars-text">
    <p>{calculateStars(userProgressExists).text}</p>
  </div>
    </div>
                    ) : (
                      <button className="button-81" onClick={()=>{
                        navigate('/playGame', { state: { story: story }}); 
                      }}>Play Story</button>
                    )
                  ) : (
                    <>
                      <button className="button-81" onClick={() => updateTask(story)}>Update Story</button>
                      <button className="button-81">Delete Story</button>
                    </>
                  )}

                </div>
              </div>
            );
          })}

      </div>
      </div>
      )}
    </div>
);

};

export default MainPage;
