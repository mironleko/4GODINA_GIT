import React, { useState, useEffect } from "react";
import './Story.css';

import { useNavigate } from 'react-router-dom';

const Story = () => {
  document.body.style.backgroundImage = "url('background.jpg')";
  document.body.style.backgroundSize = "100% 100%";

  // Mock data
  const [stories, setStories] = useState([
    { id: 1, title: 'Story 1', description: 'This is story 1' },
    { id: 2, title: 'Story 2', description: 'This is story 2' },
    { id: 3, title: 'Story 2', description: 'This is story 2' },
    { id: 4, title: 'Story 2', description: 'This is story 2' },
    { id: 5, title: 'Story 2', description: 'This is story 2' },
    { id: 6, title: 'Story 2', description: 'This is story 2' },
    { id: 7, title: 'Story 2', description: 'This is story 2' },
    { id: 8, title: 'Story 2', description: 'This is story 2' },
    { id: 9, title: 'Story 2', description: 'This is story 2' },
    { id: 10, title: 'Story 2', description: 'This is story 2' },
    { id: 11, title: 'Story 2', description: 'This is story 2' },

    // add more stories here...
  ]);

  const navigate = useNavigate();

  const handlePlay = (storyId) => {
    // Implement your play story logic here
    console.log(`Playing story with id: ${storyId}`);
  };

  const handleUpdate = (storyId) => {
    // Implement your update story logic here
    console.log(`Updating story with id: ${storyId}`);
    // Example: navigation to the update page
    // navigate(`/update/${storyId}`);
  };

  return (
    <div className='story-container'>
      {stories.map((story) => (
        <div key={story.id} className='story'>
          <h2>{story.title}</h2>
          <p>{story.description}</p>
          <button onClick={() => handlePlay(story.id)}>Play</button>
          <button onClick={() => handleUpdate(story.id)}>Update</button>
        </div>
      ))}
    </div>
  );
};

export default Story;
