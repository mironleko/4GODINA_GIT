import React, { useState,useEffect } from "react";
import './Login.css'
import { CssVarsProvider } from '@mui/joy/styles';
import Sheet from '@mui/joy/Sheet';
import Typography from '@mui/joy/Typography';
import FormControl from '@mui/joy/FormControl';
import FormLabel from '@mui/joy/FormLabel';
import Input from '@mui/joy/Input';
import Button from '@mui/joy/Button';
import Link from '@mui/joy/Link';
import { useColorScheme } from '@mui/joy/styles';
import { useNavigate } from 'react-router-dom';
function ModeToggle() {
   const { mode, setMode } = useColorScheme();
   const [mounted, setMounted] = React.useState(false);

   React.useEffect(() => {
      setMounted(true);
   }, []);
   if (!mounted) {
      return null;
   }

   return (
      <Button className="buttonLightDarkLogin"
         variant="outlined"
         onClick={() => {
            setMode(mode === 'light' ? 'dark' : 'light');
         }}
      >
         {mode === 'light' ? 'Turn dark' : 'Turn light'}
      </Button>
   );
}
const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
   e.preventDefault();
   const student = { username, password };
   fetch("http://localhost:8080/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(student)
   }).then((res) => {
      if (res.status === 200) {
         console.log(res);
         console.log("In");
         localStorage.setItem('token', res);
         localStorage.setItem('username', student.username);
         navigate('/profile')
      } else {
         console.log(res);
         console.log("wrong");
      }
   })
};

  return (
   <div className='boxLogin'>
         <div>
            <CssVarsProvider>
               <CssVarsProvider>
                  <ModeToggle />
                  <Sheet className="loginBox"
                     sx={{
                        width: 300,
                        mx: 'auto', // margin left & right
                        my: 4, // margin top & botom
                        py: 3, // padding top & bottom
                        px: 2, // padding left & right
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 2,
                        borderRadius: 'sm',
                        boxShadow: 'md',
                     }}
                  >


                     <FormControl>
                        <FormLabel>Username</FormLabel>
                        <Input
                           name="username"
                           type="username"
                           placeholder="john123"
                           value={username}
                           onInput={e => setUsername(e.target.value)}
                        />
                     </FormControl>
                     <FormControl>
                        <FormLabel>Password</FormLabel>
                        <Input
                           name="password"
                           type="password"
                           placeholder="password"
                           value={password}
                           onInput={e => setPassword(e.target.value)}
                        />
                     </FormControl>
                     <Button sx={{ mt: 1 /* margin top */ }} onClick={handleSubmit}>
                        Log in
                     </Button>
                     <Typography
                        endDecorator={<Link href="/registration">Sign up</Link>}
                        fontSize="sm"
                        sx={{ alignSelf: 'center' }}
                     >
                        Don't have an account?
                     </Typography>

                  </Sheet>
               </CssVarsProvider>
            </CssVarsProvider>
         </div>


      </div>
  );
};

export default Login;