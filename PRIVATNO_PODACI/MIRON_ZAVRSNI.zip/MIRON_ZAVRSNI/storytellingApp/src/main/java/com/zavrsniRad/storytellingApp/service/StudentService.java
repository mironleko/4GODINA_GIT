package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface StudentService {
    public Student saveStudent(Student student);
    public List<Student> getAllStudents();

    Student getStudent(String username);
}
