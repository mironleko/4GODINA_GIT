package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Task;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TaskService {
    public Task save(Task task);
    public Optional<Task> findById(int id);
    public Optional<Task> findByQuestion(String question);

    public List<Task> findAll();

    public void delete(Task task);

    public void update(Task task);
}
