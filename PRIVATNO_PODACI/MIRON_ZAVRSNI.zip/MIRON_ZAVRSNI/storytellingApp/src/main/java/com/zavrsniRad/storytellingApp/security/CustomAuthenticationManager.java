package com.zavrsniRad.storytellingApp.security;


import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.service.StudentService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.GlobalAuthenticationConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;



@Component
@AllArgsConstructor
public class CustomAuthenticationManager implements AuthenticationManager {
    @Autowired
    private StudentService studentService;

    private BCryptPasswordEncoder bCryptPasswordEncoder;




    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        Student student = studentService.getStudent(authentication.getName());


        if(!bCryptPasswordEncoder.matches(authentication.getCredentials().toString(), student.getPassword())) {

            throw new BadCredentialsException("Wrong password");
        }
        return new UsernamePasswordAuthenticationToken(authentication.getName(), student.getPassword());
    }
}

