package com.zavrsniRad.storytellingApp.dto;

import com.zavrsniRad.storytellingApp.model.Task;

public class ReturnSceneDTO {
    private int id;
    private String storyName;
    private String name;
    private String description;
    private String image;
    private double xCoordinate;
    private double yCoordinate;
    private int correctAnswerSceneId;
    private int wrongAnswerSceneId;

    private int idTask;
    private Task task;
    public ReturnSceneDTO(int id,String storyName, String name, String description, String image,double xCoordinate,double yCoordinate,int correctAnswerSceneId,int wrongAnswerSceneId) {
        this.id = id;
        this.storyName = storyName;
        this.name = name;
        this.description = description;
        this.image = image;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.correctAnswerSceneId = correctAnswerSceneId;
        this.wrongAnswerSceneId = wrongAnswerSceneId;
    }

    public String getStoryName() {
        return storyName;
    }

    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getxCoordinate() {
        return xCoordinate;
    }

    public void setxCoordinate(double xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public double getyCoordinate() {
        return yCoordinate;
    }

    public void setyCoordinate(double yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public int getCorrectAnswerSceneId() {
        return correctAnswerSceneId;
    }

    public void setCorrectAnswerSceneId(int correctAnswerSceneId) {
        this.correctAnswerSceneId = correctAnswerSceneId;
    }

    public int getWrongAnswerSceneId() {
        return wrongAnswerSceneId;
    }

    public void setWrongAnswerSceneId(int wrongAnswerSceneId) {
        this.wrongAnswerSceneId = wrongAnswerSceneId;
    }

    public int getIdTask() {
        return idTask;
    }

    public void setIdTask(int idTask) {
        this.idTask = idTask;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }
}
