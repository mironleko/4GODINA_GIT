package com.zavrsniRad.storytellingApp.dto;

import org.springframework.web.multipart.MultipartFile;

public class SceneDTO {
    private String id;
    private String storyName;
    private String name;
    private String description;
    private MultipartFile selectedImage;
    public String getStoryName() {
        return storyName;
    }
    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public MultipartFile getSelectedImage() {
        return selectedImage;
    }
    public void setSelectedImage(MultipartFile selectedImage) {
        this.selectedImage = selectedImage;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
