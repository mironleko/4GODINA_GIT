package com.zavrsniRad.storytellingApp.model;

import jakarta.persistence.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_progress")
public class UserProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Student student;
    @ManyToOne
    @JoinColumn(name = "story_id", nullable = false)
    private Story story;
    @ManyToOne
    @JoinColumn(name = "scene_id", nullable = false)
    private Scene scene;

    @ManyToOne
    @JoinColumn(name = "task_id", nullable = false)
    private Task task;

    @Column(name = "is_correct", nullable = false)
    private boolean isCorrect;

    @Column(name = "timestamp", nullable = false)
    private Timestamp timestamp;

    public UserProgress() {
    }
    public UserProgress(Student student, Story story, Scene scene, Task task, boolean isCorrect, Timestamp timestamp) {
        this.student = student;
        this.story = story;
        this.scene = scene;
        this.task = task;
        this.isCorrect = isCorrect;
        this.timestamp = timestamp;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Story getStory() {
        return story;
    }

    public void setStory(Story story) {
        this.story = story;
    }

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    public void setCorrect(boolean correct) {
        isCorrect = correct;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}
