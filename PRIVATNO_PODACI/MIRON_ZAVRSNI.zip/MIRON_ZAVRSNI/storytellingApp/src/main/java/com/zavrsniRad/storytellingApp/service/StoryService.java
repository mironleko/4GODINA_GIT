package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Story;
import com.zavrsniRad.storytellingApp.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface StoryService {
    public Story saveStory(Story story);
    public List<Story> findAll();

    public Optional<Story> findByName(String name);

    public Story update(Story story);
}
