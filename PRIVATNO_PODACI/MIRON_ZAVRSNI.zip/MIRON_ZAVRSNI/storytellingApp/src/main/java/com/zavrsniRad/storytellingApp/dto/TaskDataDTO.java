package com.zavrsniRad.storytellingApp.dto;

import java.util.Map;

public class TaskDataDTO {

    private String question;

    private Map<String, String> options;

    private String correctAnswer;

    public TaskDataDTO() {
    }

    public TaskDataDTO(String question, Map<String, String> options, String correctAnswer) {
        this.question = question;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Map<String, String> getOptions() {
        return options;
    }

    public void setOptions(Map<String, String> options) {
        this.options = options;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}