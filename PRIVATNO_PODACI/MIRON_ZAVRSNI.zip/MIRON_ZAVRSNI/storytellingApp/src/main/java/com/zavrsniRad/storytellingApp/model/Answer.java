package com.zavrsniRad.storytellingApp.model;

public class Answer {
}
