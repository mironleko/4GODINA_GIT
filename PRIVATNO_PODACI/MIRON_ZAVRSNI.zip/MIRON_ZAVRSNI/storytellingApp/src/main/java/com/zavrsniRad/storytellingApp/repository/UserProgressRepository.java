package com.zavrsniRad.storytellingApp.repository;

import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.model.UserProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserProgressRepository extends JpaRepository<UserProgress,Integer> {
    public UserProgress save(UserProgress userProgress);
    public Optional<UserProgress> findById(int id);
    public List<UserProgress> findAll();
    List<UserProgress> findByStudent(Student student);
    @Transactional
    @Query("SELECT up.id, up.student, up.story, up.scene, up.task, up.isCorrect FROM UserProgress up WHERE up.student.username = :username")
    List<Object[]> findUserProgressByStudentUsername(@Param("username") String username);

}
