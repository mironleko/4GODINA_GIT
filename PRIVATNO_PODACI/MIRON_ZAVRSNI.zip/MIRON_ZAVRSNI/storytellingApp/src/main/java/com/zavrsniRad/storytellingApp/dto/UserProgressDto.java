package com.zavrsniRad.storytellingApp.dto;

public class UserProgressDto {

    private String username;
    private String storyName;
    private int sceneId;
    private boolean correctAnswer;

    public UserProgressDto() {
    }

    public UserProgressDto(String username, String storyName, int sceneId, boolean correctAnswer) {
        this.username = username;
        this.storyName = storyName;
        this.sceneId = sceneId;
        this.correctAnswer = correctAnswer;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStoryName() {
        return storyName;
    }

    public void setStoryName(String storyName) {
        this.storyName = storyName;
    }

    public int getSceneId() {
        return sceneId;
    }

    public void setSceneId(int sceneId) {
        this.sceneId = sceneId;
    }

    public boolean isCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(boolean correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}

