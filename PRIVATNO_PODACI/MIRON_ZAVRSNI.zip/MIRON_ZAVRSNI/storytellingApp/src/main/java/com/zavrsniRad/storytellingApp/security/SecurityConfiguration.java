package com.zavrsniRad.storytellingApp.security;
import jakarta.servlet.Filter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.GlobalAuthenticationConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.IOException;
import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration  {
    @Autowired
    private CustomAuthenticationManager customAuthenticationManager;

    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**").allowedOrigins("*").allowedMethods("*");
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        AuthentificationFilter authentificationFilter = new AuthentificationFilter(customAuthenticationManager);
        authentificationFilter.setFilterProcessesUrl("/login");

        http
                .cors().and()
                .csrf().disable()
                .authorizeRequests()
                .requestMatchers("/public/**").permitAll()
                .requestMatchers(HttpMethod.POST,  "/registration").permitAll()
                .requestMatchers(HttpMethod.POST,  "/story/createStory").permitAll()
                .requestMatchers(HttpMethod.POST,  "/scene/**").permitAll()
                .requestMatchers(HttpMethod.POST,  "/task/createTask").permitAll()
                .requestMatchers(HttpMethod.GET,  "/scene/getScenes/**").permitAll()
                .requestMatchers(HttpMethod.GET,  "/task/getTasks").permitAll()
                .requestMatchers(HttpMethod.GET,  "/user/getData").permitAll()
                .requestMatchers(HttpMethod.GET,  "/story/getStories").permitAll()
                .requestMatchers(HttpMethod.POST,  "/story/saveStory").permitAll()
                .requestMatchers(HttpMethod.POST,  "/task/deleteTask").permitAll()
                .requestMatchers(HttpMethod.POST,  "/story/removeNode").permitAll()
                .requestMatchers(HttpMethod.POST,  "/scene/addTask").permitAll()
                .requestMatchers(HttpMethod.GET,  "/task/getTasksWithoutScene").permitAll()
                .requestMatchers(HttpMethod.POST,  "/story/setStoryReady").permitAll()
                .requestMatchers(HttpMethod.GET,  "/story/getFirstScene/**").permitAll()
                .requestMatchers(HttpMethod.POST,  "/story/setFirstNode").permitAll()
                .requestMatchers(HttpMethod.GET,  "/scene/getTaskForScene/**").permitAll()
                .requestMatchers(HttpMethod.GET,  "/scene/getNextScene/**").permitAll()
                .requestMatchers(HttpMethod.POST,  "/task/createMultipleChoiceTask").permitAll()
                .requestMatchers(HttpMethod.POST,  "/userProgress/addNew").permitAll()
                .requestMatchers(HttpMethod.GET,  "/userProgress/getProgress").permitAll()

                .anyRequest().authenticated()
                .and()
                .addFilterBefore(new ExceptionHandlerFilter(), AuthentificationFilter.class)
                .addFilter(authentificationFilter)
                .addFilterAfter(new JWTAuthorizationFilter(), AuthentificationFilter.class)
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.addAllowedOrigin("http://localhost:3000");
        configuration.addAllowedHeader("*");
        configuration.addAllowedMethod("*");
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);

        return source;
    }




}

