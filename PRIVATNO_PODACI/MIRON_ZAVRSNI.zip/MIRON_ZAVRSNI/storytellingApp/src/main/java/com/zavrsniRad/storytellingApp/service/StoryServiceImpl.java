package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Story;
import com.zavrsniRad.storytellingApp.repository.StoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StoryServiceImpl implements StoryService{

    @Autowired
    StoryRepository storyRepository;
    @Override
    public Story saveStory(Story story) {
        return storyRepository.save(story);
    }

    @Override
    public List<Story> findAll() {
        return storyRepository.findAll();
    }

    @Override
    public Optional<Story> findByName(String name) {
        return storyRepository.findByName(name);
    }

    @Override
    public Story update(Story story) {
        return storyRepository.save(story);
    }


}
