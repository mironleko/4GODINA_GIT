package com.zavrsniRad.storytellingApp.repository;

import com.zavrsniRad.storytellingApp.model.Story;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StoryRepository extends JpaRepository<Story,Integer> {
    public Story save(Story story);
    public Optional<Story> findById(int id);
    public Optional<Story> findByName(String name);

    public List<Story> findAll();
}
