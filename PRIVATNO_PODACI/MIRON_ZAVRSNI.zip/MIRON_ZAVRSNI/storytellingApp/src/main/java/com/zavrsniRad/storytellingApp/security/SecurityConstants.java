package com.zavrsniRad.storytellingApp.security;

public class SecurityConstants {
    public static final int TOKEN_EXPIRATION = 7200000; //(2H)
    public static final String SECRET_KEY = "D*G-KaPdSgVkXp2s5v8y/B?E(H+MbQeThWmZq3t6w9z$C&F)J@NcRfUjXn2r5u7x";
    public static final String BEARER = "Bearer ";
    public static final String AUTHORIZATION = "Authorization";
}
