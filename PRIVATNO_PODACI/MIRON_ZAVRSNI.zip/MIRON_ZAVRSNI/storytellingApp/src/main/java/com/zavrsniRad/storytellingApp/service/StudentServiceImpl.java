package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.exception.EntityNotFoundException;
import com.zavrsniRad.storytellingApp.exception.RegistrationException;
import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.repository.StudentRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class StudentServiceImpl implements StudentService{

    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    public BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student getStudent(String username) {
        Optional<Student> student = studentRepository.findByUsername(username);
        return unwrapKlijent(student, 404L);

    }

    static Student unwrapKlijent(Optional<Student> entity, Long id) {
        if (entity.isPresent()) return  entity.get();
        else throw new EntityNotFoundException(id, Student.class);
    }

    public void register(Student student) throws UnsupportedEncodingException {
        if (student.getPassword() == null) {
            throw new IllegalArgumentException("Password cannot be null");
        }
        student.setPassword(bCryptPasswordEncoder.encode(student.getPassword()));

        student.setEnabled(true);

        if (studentRepository.countByUsername(student.getUsername()) > 0) {
            throw new RegistrationException("Odabrano korisničko ime je već zauzeto.");
        } else {
            studentRepository.save(student);
        }

    }
}

