package com.zavrsniRad.storytellingApp.controller;

import com.zavrsniRad.storytellingApp.dto.UserProgressDto;
import com.zavrsniRad.storytellingApp.model.*;
import com.zavrsniRad.storytellingApp.service.SceneService;
import com.zavrsniRad.storytellingApp.service.StoryService;
import com.zavrsniRad.storytellingApp.service.StudentService;
import com.zavrsniRad.storytellingApp.service.UserProgressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/userProgress")
public class UserProgressController {

    @Autowired
    UserProgressService userProgressService;

    @Autowired
    StoryService storyService;

    @Autowired
    StudentService studentService;
    @Autowired
    SceneService sceneService;
    @PostMapping("/addNew")
    public ResponseEntity<Object> addNewUserProgress(@RequestBody UserProgressDto userProgressDto){
        Optional<Story> story = storyService.findByName(userProgressDto.getStoryName());
        Student student = studentService.getStudent(userProgressDto.getUsername());
        Optional<Scene> scene = sceneService.findById(userProgressDto.getSceneId());
        Task task = null;
        if(scene.isPresent()){
            task = scene.get().getTask();
        }
        if(scene.isPresent() && student != null && story.isPresent() && task != null) {
            Timestamp timestamp = Timestamp.valueOf(LocalDateTime.now());

            UserProgress userProgress = new UserProgress(student, story.get(), scene.get(), task, userProgressDto.isCorrectAnswer(), timestamp);
            userProgressService.save(userProgress);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @GetMapping("/getProgress")
    public List<UserProgress> getProgress(@RequestParam String username) {
        Student student = studentService.getStudent(username);
        if (student == null) {
            // handle the case where there's no student with the given username
            return null;
        }
        return userProgressService.getUserProgressByUsername(username);
    }
}
