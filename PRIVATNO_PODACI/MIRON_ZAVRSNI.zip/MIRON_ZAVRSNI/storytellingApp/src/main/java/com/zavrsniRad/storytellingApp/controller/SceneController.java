package com.zavrsniRad.storytellingApp.controller;

import com.zavrsniRad.storytellingApp.dto.*;
import com.zavrsniRad.storytellingApp.model.Scene;
import com.zavrsniRad.storytellingApp.model.Story;
import com.zavrsniRad.storytellingApp.model.Task;
import com.zavrsniRad.storytellingApp.service.SceneService;
import com.zavrsniRad.storytellingApp.service.StoryService;
import com.zavrsniRad.storytellingApp.service.TaskService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/scene")
public class SceneController {
    @Autowired
    StoryService storyService;

    @Autowired
    SceneService sceneService;

    @Autowired
    TaskService taskService;
    @PostMapping("/createScene")
    public Object createScene(SceneDTO sceneDTO, HttpServletRequest request) throws IOException {
        Story story = storyService.findByName(sceneDTO.getStoryName()).get();
        System.out.println(sceneDTO.getSelectedImage().getOriginalFilename());

        String fileName = StringUtils.cleanPath((sceneDTO.getSelectedImage()).getOriginalFilename());

        Scene scene = new Scene(sceneDTO.getName(),sceneDTO.getDescription(),fileName,story);
        String uploadDir = "photo/" + story.getName();

        Path uploadPath = Paths.get(uploadDir);

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        try (InputStream inputStream = sceneDTO.getSelectedImage().getInputStream()) {
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {
            throw new IOException("Could not save image file: " + fileName, ioe);
        }
        sceneService.save(scene);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @GetMapping("/getScenes/{storyName}")
    public List<ReturnSceneDTO> getAllScenesFromStory(@PathVariable String storyName, HttpServletRequest request) throws IOException {
        List<Scene> scenes = sceneService.findAll();
        Story story = storyService.findByName(storyName).get();

        scenes = sceneService.findScenesByStoryName(story.getId());
        List<ReturnSceneDTO> returnScenes = new ArrayList<>();

        for(Scene scene:scenes){
            Path path = Paths.get("photo/" + scene.getStory().getName() + "/" + scene.getImage());

            byte[] bytes = StreamUtils.copyToByteArray(new FileInputStream(path.toFile()));
            String imageBase64 = Base64.getEncoder().encodeToString(bytes);

            ReturnSceneDTO returnSceneDTO = new ReturnSceneDTO(scene.getId(),scene.getStory().getName(),scene.getName(),scene.getDescription(),imageBase64,scene.getxCoordinate(),scene.getyCoordinate(),scene.getCorrectAnswerSceneId(),scene.getWrongAnswerSceneId());
            if(scene.getTask() != null) {
                returnSceneDTO.setIdTask(scene.getTask().getId());
                returnSceneDTO.setTask(scene.getTask());
            }else{
                returnSceneDTO.setIdTask(0);
            }
            returnScenes.add(returnSceneDTO);
        }
        returnScenes.sort(Comparator.comparing(ReturnSceneDTO::getId));

        return returnScenes;
    }

    @GetMapping("/getTaskForScene/{id}")
    public Task getSceneDetails(@PathVariable int id, HttpServletRequest request){
        Scene scene = sceneService.findById(id).get(); // replace with your own method to get the Scene object from your database

        if (scene == null) {
            return null;
        }

        Task task = scene.getTask();

        return task;
    }

    @GetMapping("/getNextScene/{nextSceneId}")
    public ReturnSceneDTO getNextScene(@PathVariable int nextSceneId, HttpServletRequest request) throws IOException {
        Scene scene = sceneService.findById(nextSceneId).orElse(null);
        if(scene == null){
            return null;
        }
        Path path = Paths.get("photo/" + scene.getStory().getName() + "/" + scene.getImage());

        byte[] bytes = StreamUtils.copyToByteArray(new FileInputStream(path.toFile()));
        String imageBase64 = Base64.getEncoder().encodeToString(bytes);

        ReturnSceneDTO returnSceneDTO = new ReturnSceneDTO(scene.getId(),scene.getStory().getName(),scene.getName(),scene.getDescription(),imageBase64,scene.getxCoordinate(),scene.getyCoordinate(),scene.getCorrectAnswerSceneId(),scene.getWrongAnswerSceneId());
        if(scene.getTask() != null) {
            returnSceneDTO.setIdTask(scene.getTask().getId());
            returnSceneDTO.setTask(scene.getTask());
        }else{
            returnSceneDTO.setIdTask(0);
        }
        return returnSceneDTO;
    }

    @PostMapping("/deleteScene")
    public ResponseEntity<Object> deleteScene(@RequestBody SceneDTO sceneDTO){
        Optional<Scene> scene = sceneService.findById(Integer.valueOf(sceneDTO.getId()));
        sceneService.delete(scene.get());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/updateScene")
    public ResponseEntity<Object> updateScene(@ModelAttribute SceneDTO sceneDTO,HttpServletRequest request) throws IOException {
        System.out.println("tuuu");
        Scene existingScene = sceneService.findById(Integer.valueOf(sceneDTO.getId()))
                .orElseThrow(() -> new RuntimeException("Scene not found with id: " + sceneDTO.getId()));

        // Handle the image replacement...
        Story story = storyService.findByName(sceneDTO.getStoryName()).get();
        String oldFileName = existingScene.getImage();  // Assuming you have a getter for the image name

        String uploadDir = "photo/" + story.getName();

        Path uploadPath = Paths.get(uploadDir);

        String fileName = null;
        existingScene.setName(sceneDTO.getName());
        existingScene.setDescription(sceneDTO.getDescription());
        if(!sceneDTO.getSelectedImage().isEmpty() && !sceneDTO.getSelectedImage().getOriginalFilename().equals("empty.jpg")) {
            fileName = StringUtils.cleanPath(sceneDTO.getSelectedImage().getOriginalFilename());
            existingScene.setImage(fileName);
        } else {
            System.out.println("Lekooooo");

        }

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        if(sceneDTO.getSelectedImage() != null && !sceneDTO.getSelectedImage().getOriginalFilename().equals("empty.jpg")) {
            try (InputStream inputStream = sceneDTO.getSelectedImage().getInputStream()) {
                Path filePath = uploadPath.resolve(fileName);
                Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ioe) {
                throw new IOException("Could not save image file: " + fileName, ioe);
            }
        }

        sceneService.update(existingScene);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @PostMapping("/saveScenesOrder")
    public ResponseEntity<Object> saveScenesOrder(@RequestBody SaveStoryDTO storyDTOS, HttpServletRequest request){

        return new ResponseEntity<Object>(HttpStatus.OK);
    }


    @PostMapping("/addTask")
    public ResponseEntity<Object> addTask(@RequestBody TaskDTO taskDTO, HttpServletRequest request){
        Scene scene = sceneService.findById(taskDTO.getSceneId()).get();
        if(scene == null){
            //exception
        }

        Task task = taskService.findById(taskDTO.getId()).get();

        if(task == null){
            //exception
        }

        scene.setTask(task);
        sceneService.update(scene);

        return new ResponseEntity<>(HttpStatus.OK);
    }
    @GetMapping("/getScenes")
    public Page<ReturnSceneDTO> getScenes(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int pageSize
    ) throws IOException {
        Pageable pageable = PageRequest.of(page-1, pageSize);
        Page<Scene> scenePage = sceneService.findAllPaged(page-1,pageSize);

        List<ReturnSceneDTO> returnScenes = new ArrayList<>();
        for (Scene scene : scenePage.getContent()) {
            Path path = Paths.get("photo/" + scene.getStory().getName() + "/" + scene.getImage());
            byte[] bytes = Files.readAllBytes(path);
            String imageBase64 = Base64.getEncoder().encodeToString(bytes);

            ReturnSceneDTO returnSceneDTO = new ReturnSceneDTO(
                    scene.getId(),
                    scene.getStory().getName(),
                    scene.getName(),
                    scene.getDescription(),
                    imageBase64,
                    scene.getxCoordinate(),
                    scene.getyCoordinate(),
                    scene.getCorrectAnswerSceneId(),
                    scene.getWrongAnswerSceneId()
            );

            if (scene.getTask() != null) {
                returnSceneDTO.setIdTask(scene.getTask().getId());
                returnSceneDTO.setTask(scene.getTask());
            } else {
                returnSceneDTO.setIdTask(0);
            }

            returnScenes.add(returnSceneDTO);
        }
        return new PageImpl<>(returnScenes, pageable, scenePage.getTotalElements());
    }

}
