package com.zavrsniRad.storytellingApp.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.JsonGetter;

import java.util.Map;

public class NodeDTO {
    private String label;
    private String description;
    private String image;
    private boolean dragging;
    private int height;
    private String id;
    private Map<String, Double> position;
    private Map<String, Double> positionAbsolute;
    private boolean selected;
    private Map<String, String> style;
    private String type;
    private int width;

    // Constructors

    public NodeDTO() {
    }

    // Getters and Setters

    @JsonProperty("label")
    public String getLabel() {
        return label;
    }

    @JsonProperty("label")
    public void setLabel(String label) {
        this.label = label;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("image")
    public String getImage() {
        return image;
    }

    @JsonProperty("image")
    public void setImage(String image) {
        this.image = image;
    }

    @JsonProperty("dragging")
    public boolean isDragging() {
        return dragging;
    }

    @JsonProperty("dragging")
    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }

    @JsonProperty("height")
    public int getHeight() {
        return height;
    }

    @JsonProperty("height")
    public void setHeight(int height) {
        this.height = height;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("position")
    public Map<String, Double> getPosition() {
        return position;
    }

    @JsonProperty("position")
    public void setPosition(Map<String, Double> position) {
        this.position = position;
    }

    @JsonProperty("positionAbsolute")
    public Map<String, Double> getPositionAbsolute() {
        return positionAbsolute;
    }

    @JsonProperty("positionAbsolute")
    public void setPositionAbsolute(Map<String, Double> positionAbsolute) {
        this.positionAbsolute = positionAbsolute;
    }

    @JsonProperty("selected")
    public boolean isSelected() {
        return selected;
    }

    @JsonProperty("selected")
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @JsonProperty("style")
    public Map<String, String> getStyle() {
        return style;
    }

    @JsonProperty("style")
    public void setStyle(Map<String, String> style) {
        this.style = style;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("width")
    public int getWidth() {
        return width;
    }

    @JsonProperty("width")
    public void setWidth(int width) {
        this.width = width;
    }
}
