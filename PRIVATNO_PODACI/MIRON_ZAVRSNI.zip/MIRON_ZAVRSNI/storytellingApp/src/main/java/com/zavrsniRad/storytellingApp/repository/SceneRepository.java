package com.zavrsniRad.storytellingApp.repository;

import com.zavrsniRad.storytellingApp.model.Scene;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface SceneRepository extends JpaRepository<Scene,Integer> {
    public Scene save(Scene scene);
    public Optional<Scene> findById(int id);
    public Optional<Scene> findByName(String name);

    public List<Scene> findAll();
    @Query("SELECT s FROM Scene s WHERE s.story.id = :storyId")
    List<Scene> findByStoryId(@Param("storyId") int storyId);

    @Query("SELECT s.id FROM Scene s WHERE s.task.id = :taskId")
    Optional<Integer> findByTaskId(Integer taskId);

    Page<Scene> findAll(Pageable pageable);

}
