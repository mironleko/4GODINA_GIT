package com.zavrsniRad.storytellingApp.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "scene")
public class Scene {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true)
    private String name;

    @Lob
    private String description;

    private String image;

    private boolean isFirst;
    @ManyToOne
    @JoinColumn(name = "story_id")
    private Story story;
    @JsonManagedReference
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "task_id", referencedColumnName = "id")
    private Task task;
    private int correctAnswerSceneId;
    private int wrongAnswerSceneId;
    private double xCoordinate;
    private double yCoordinate;

    public Scene(){

    }

    public Scene(String name, String description, String image, Story story) {
        this.name = name;
        this.description = description;
        this.image = image;
        this.story = story;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Story getStory() {
        return story;
    }

    public void setStory(Story story) {
        this.story = story;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCorrectAnswerSceneId() {
        return correctAnswerSceneId;
    }

    public void setCorrectAnswerSceneId(int correctAnswerSceneId) {
        this.correctAnswerSceneId = correctAnswerSceneId;
    }

    public int getWrongAnswerSceneId() {
        return wrongAnswerSceneId;
    }

    public void setWrongAnswerSceneId(int wrongAnswerSceneId) {
        this.wrongAnswerSceneId = wrongAnswerSceneId;
    }

    public double getxCoordinate() {
        return xCoordinate;
    }

    public void setxCoordinate(double xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public double getyCoordinate() {
        return yCoordinate;
    }

    public void setyCoordinate(double yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public boolean isFirst() {
        return isFirst;
    }

    public void setFirst(boolean first) {
        isFirst = first;
    }
}