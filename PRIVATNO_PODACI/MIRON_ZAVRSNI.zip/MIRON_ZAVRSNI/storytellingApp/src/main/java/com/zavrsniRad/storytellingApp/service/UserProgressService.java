package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.model.UserProgress;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface UserProgressService {
    public UserProgress save(UserProgress userProgress);
    public Optional<UserProgress> findById(int id);
    public List<UserProgress> findAll();
    public List<UserProgress> findByStudent(Student student);
    public List<UserProgress> getUserProgressByUsername(String username);
}
