package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Scene;
import com.zavrsniRad.storytellingApp.model.Story;
import com.zavrsniRad.storytellingApp.repository.SceneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class SceneServiceImpl implements SceneService{
    @Autowired
    SceneRepository sceneRepository;
    @Override
    public Scene save(Scene scene) {
        return sceneRepository.save(scene);
    }

    @Override
    public Optional<Scene> findById(int id) {
        return sceneRepository.findById(id);
    }

    @Override
    public Optional<Scene> findByName(String name) {
        return sceneRepository.findByName(name);
    }

    @Override
    public List<Scene> findAll() {
        return sceneRepository.findAll();
    }

    @Override
    public void delete(Scene scene) {
        sceneRepository.delete(scene);
    }

    @Override
    public void update(Scene scene){
        sceneRepository.save(scene);
    }

    @Override
    public void deleteConnectionsBySceneId(int sceneId) {
        List<Scene> connectedScenes = sceneRepository.findAll();

        for (Scene s : connectedScenes) {
            if (s.getCorrectAnswerSceneId() == sceneId) {
                s.setCorrectAnswerSceneId(0);
            }
            if (s.getWrongAnswerSceneId() == sceneId) {
                s.setWrongAnswerSceneId(0);
            }
        }

        sceneRepository.saveAll(connectedScenes);
    }
    @Override
    @Transactional
    public List<Scene> findScenesByStoryName(int id) {
        return sceneRepository.findByStoryId(id);
    }

    @Override
    public Optional<Integer> findByTaskId(int taskId) {
        return sceneRepository.findByTaskId(taskId);
    }

    @Override
    @Transactional
    public List<Scene> findByStoryId(int id) {
        return sceneRepository.findByStoryId(id);
    }
    @Override
    public Page<Scene> findAllPaged(int page, int pageSize) {
        Pageable pageable = PageRequest.of(page, pageSize);
        return sceneRepository.findAll(pageable);
    }
}
