package com.zavrsniRad.storytellingApp.controller;

import com.zavrsniRad.storytellingApp.dto.StudentRegDTO;
import com.zavrsniRad.storytellingApp.model.Authority;
import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.repository.StudentRepository;
import com.zavrsniRad.storytellingApp.service.StudentService;
import com.zavrsniRad.storytellingApp.service.StudentServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.List;


@RestController
@RequestMapping
@CrossOrigin
public class StudentController {
    @Autowired
    private StudentServiceImpl studentService;

    @Autowired
    private StudentRepository studentRepository;

    @PostMapping(path="/registration")
    @CrossOrigin(origins = "http://localhost:3000")
    public Student processRegister(@RequestBody StudentRegDTO studentRegDTO, HttpServletRequest request) throws UnsupportedEncodingException {
        Student student = new Student();
        student.setUsername(studentRegDTO.getUsername());
        student.setPassword((studentRegDTO.getPassword()));
        student.setEmail(studentRegDTO.getEmail());
        student.setLastname(studentRegDTO.getLastname());
        student.setName(studentRegDTO.getName());
        student.setAuthority(Authority.STUDENT);
        student.setEnabled(true);
        studentService.register(student);
        return student;
    }

    @PostMapping("/form/submit")
    public String handleFormSubmission(@RequestParam("comment") String comment) {
        // Handle the form submission here
        System.out.println("Received comment: " + comment);
        // Return the name of the view to render
        return "success";
    }

    @PostMapping("/logout")
    public void logout(@Param("jwt") String token) {

    }

   /* @PostMapping("/add")
    @CrossOrigin(origins = "http://localhost:3000")
    public String add(@RequestBody Student student) {
        studentService.saveStudent(student);
        return "New student is added";
    }

    @GetMapping("/getAll")
    @CrossOrigin(origins = "http://localhost:3000")
    public List<Student> getAllStudents() {

        return studentService.getAllStudents();
    }*/


   /* @GetMapping("/check_login_status")
    public ResponseEntity<String> checkLoginStatus(HttpServletRequest request) {
        String token = getTokenFromRequest(request);
        if (token != null && jwtTokenUtil.validateToken(token)) {
            return ResponseEntity.ok("User is logged in.");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User is not logged in.");
        }
    }*/

    private String getTokenFromRequest(HttpServletRequest request) {
        final String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            return authorizationHeader.substring(7);
        }
        return null;
    }

    @GetMapping("/user/getData")
    public Student getUserData(@RequestParam String username) {
        // Retrieve user data based on the provided username
        // Replace this with your own logic to fetch the user data from your data source
        Student user = studentService.getStudent(username);
        return user;
    }

}
