package com.zavrsniRad.storytellingApp.controller;

import com.zavrsniRad.storytellingApp.dto.*;
import com.zavrsniRad.storytellingApp.model.Scene;
import com.zavrsniRad.storytellingApp.model.Story;
import com.zavrsniRad.storytellingApp.model.Student;
import com.zavrsniRad.storytellingApp.service.SceneService;
import com.zavrsniRad.storytellingApp.service.StoryService;
import com.zavrsniRad.storytellingApp.service.StudentService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.w3c.dom.Node;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("/story")
@CrossOrigin
public class StoryController {
    @Autowired
    StoryService storyService;
    @Autowired
    SceneService sceneService;
    @Autowired
    StudentService studentService;
    @PostMapping("/createStory")
    public Object addStory(@RequestBody StoryDTO storyDTO, HttpServletRequest request){

        String username = storyDTO.getUsername();

        Student student = studentService.getStudent(username);
        Story story = new Story(storyDTO.getTitle(), storyDTO.getDescription(),false,student);
        storyService.saveStory(story);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @GetMapping("/getStories")
    public List<Story> getStories(HttpServletRequest request){

        List<Story> stories = storyService.findAll();

        return stories;
    }
    @PostMapping("/saveStory")
    public ResponseEntity<Object> saveStory(@RequestBody SaveStoryDTO storyDTOS, HttpServletRequest request){


        List<EdgeDTO> edges = storyDTOS.getEdges();
        List<NodeDTO> nodes = storyDTOS.getNodes();
        for(NodeDTO nodeDTO:nodes){
            System.out.println(nodeDTO.getId());
        }
        for(EdgeDTO edgeDTO:edges){
            Scene scene = sceneService.findById(Integer.valueOf(edgeDTO.getSource())).get();

            if(scene != null) {
                if(edgeDTO.getLabel().equals("Correct")){
                    scene.setCorrectAnswerSceneId(Integer.valueOf(edgeDTO.getTarget()));
                }else if(edgeDTO.getLabel().equals("Wrong")){
                    scene.setWrongAnswerSceneId(Integer.valueOf(edgeDTO.getTarget()));
                }
                sceneService.update(scene);
            }
        }

        for(NodeDTO nodeDTO:nodes){
            Scene scene = sceneService.findById(Integer.valueOf(nodeDTO.getId())).get();
            if(scene != null){
                scene.setxCoordinate(nodeDTO.getPosition().get("x"));
                scene.setyCoordinate((nodeDTO.getPosition().get("y")));
                sceneService.update(scene);
            }
        }


        return new ResponseEntity<Object>(HttpStatus.OK);
    }

    @PostMapping("/removeNode")
    public ResponseEntity<Object> removeNode(@RequestBody NodeDTO node, HttpServletRequest request){
        Scene scene = sceneService.findById(Integer.valueOf(node.getId())).get();

        if(scene == null) {
            return new ResponseEntity<>("Scene not found", HttpStatus.NOT_FOUND);
        }

        sceneService.deleteConnectionsBySceneId(scene.getId());

        scene.setCorrectAnswerSceneId(0);
        scene.setWrongAnswerSceneId(0);

        sceneService.update(scene);

        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/setStoryReady")
    public ResponseEntity<Object> setStoryReady(@RequestBody StoryDTO storyDTO,HttpServletRequest request){
        Story story = storyService.findByName(storyDTO.getTitle()).get();

        if(story != null){
            System.out.println("usooo");
            story.setReady(true);
            storyService.update(story);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/getFirstScene/{storyId}")
    public ReturnSceneDTO getFirstScene(@PathVariable int storyId, HttpServletRequest request) throws IOException {
        List<Scene> scenes = sceneService.findByStoryId(storyId);
        if (scenes.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Scene Not Found");
        }
        Scene sceneFirst = null;
        for(Scene scene:scenes){
            if(scene.isFirst()){
                sceneFirst= scene;
            }
        }

        Path path = Paths.get("photo/" + sceneFirst.getStory().getName() + "/" + sceneFirst.getImage());

        byte[] bytes = StreamUtils.copyToByteArray(new FileInputStream(path.toFile()));
        String imageBase64 = Base64.getEncoder().encodeToString(bytes);

        ReturnSceneDTO returnSceneDTO = new ReturnSceneDTO(sceneFirst.getId(),sceneFirst.getStory().getName(),sceneFirst.getName(),sceneFirst.getDescription(),imageBase64,sceneFirst.getxCoordinate(),sceneFirst.getyCoordinate(),sceneFirst.getCorrectAnswerSceneId(),sceneFirst.getWrongAnswerSceneId());
        if(sceneFirst.getTask() != null) {
            returnSceneDTO.setIdTask(sceneFirst.getTask().getId());
            returnSceneDTO.setTask(sceneFirst.getTask());
        }else{
            returnSceneDTO.setIdTask(0);
        }
        return returnSceneDTO;
    }

    @PostMapping("/setFirstNode")
    public ResponseEntity<Object> setFirstNode(@RequestBody StoryDTO storyDTO,HttpServletRequest request){
        Scene scene = sceneService.findById(storyDTO.getId()).get();
        scene.setFirst(true);

        sceneService.update(scene);

        return new ResponseEntity<>(HttpStatus.OK);
    }

}
