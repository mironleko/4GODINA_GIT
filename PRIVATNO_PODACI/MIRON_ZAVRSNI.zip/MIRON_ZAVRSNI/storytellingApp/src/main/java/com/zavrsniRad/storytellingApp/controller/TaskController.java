package com.zavrsniRad.storytellingApp.controller;

import com.zavrsniRad.storytellingApp.dto.TaskDTO;
import com.zavrsniRad.storytellingApp.dto.TaskDataDTO;
import com.zavrsniRad.storytellingApp.model.Scene;
import com.zavrsniRad.storytellingApp.model.Task;
import com.zavrsniRad.storytellingApp.service.SceneService;
import com.zavrsniRad.storytellingApp.service.TaskService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/task")
public class TaskController {
    @Autowired
    TaskService taskService;
    @Autowired
    SceneService sceneService;
    @PostMapping("/createTask")
    public Object createTask(@RequestBody TaskDTO taskDTO, HttpServletRequest request){
        System.out.println(taskDTO.getAnswer());
        System.out.println(taskDTO.getQuestion());
        Task task = new Task(taskDTO.getQuestion(),taskDTO.getAnswer());
        task.setQuestionType("text");
        taskService.save(task);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @GetMapping("/getTasks")
    public List<Task> getTasks(TaskDTO taskDTO, HttpServletRequest request){
        List<Task> tasks= taskService.findAll();
        List<Task> retTasks= new ArrayList<>();
        for(Task task:tasks){
            retTasks.add(task);
        }

        return retTasks;
    }

    @PostMapping("/deleteTask")
    public ResponseEntity<Object> deleteTask(@RequestBody TaskDTO taskDTO){
        Optional<Task> task = taskService.findById(taskDTO.getId());

        taskService.delete(task.get());

        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/getTasksWithoutScene")
    public List<Task> getTasksWithoutScene(HttpServletRequest request){
        List<Task> allTasks = taskService.findAll();

        List<Task> returnTasks = new ArrayList<>();

        for(Task task:allTasks){
            int taskId = task.getId();

            Optional<Integer> id = sceneService.findByTaskId(taskId);
            if(id.isEmpty()){
                returnTasks.add(task);
            }
        }

        return returnTasks;
    }
    @PostMapping("/createMultipleChoiceTask")
    public ResponseEntity<Object> createMultipleChoiceTask(@RequestBody TaskDataDTO taskDataDTO,HttpServletRequest request){
        Task task = new Task(taskDataDTO.getQuestion(),taskDataDTO.getOptions().get("A"),taskDataDTO.getOptions().get("B")
                ,taskDataDTO.getOptions().get("C"),taskDataDTO.getOptions().get("D"),taskDataDTO.getCorrectAnswer());
        task.setQuestionType("multipleChoice");
        taskService.save(task);

        return new ResponseEntity<>(HttpStatus.OK);
    }

}
