package com.zavrsniRad.storytellingApp.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "story")
public class Story {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;
    private String description;
    private boolean ready;
    @ManyToOne
    @JoinColumn(name = "author_id")
    private Student author;

    @OneToMany(mappedBy = "story", cascade = CascadeType.ALL)
    private List<Scene> scenes;
    public Story(){

    }

    public Story(String name,String description,boolean ready,Student author){
        this.name = name;
        this.description = description;
        this.author = author;
        this.ready = ready;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Student getAuthor() {
        return author;
    }

    public void setAuthor(Student author) {
        this.author = author;
    }

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean ready) {
        this.ready = ready;
    }
}
