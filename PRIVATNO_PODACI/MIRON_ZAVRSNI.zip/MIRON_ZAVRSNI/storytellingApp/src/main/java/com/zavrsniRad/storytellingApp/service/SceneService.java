package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.Scene;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface SceneService {
    public Scene save(Scene scene);
    public Optional<Scene> findById(int id);
    public Optional<Scene> findByName(String name);
    public List<Scene> findAll();
    public void delete(Scene scene);
    public void update(Scene scene);
    public void deleteConnectionsBySceneId(int sceneId);
    public List<Scene> findScenesByStoryName(int id);

    public Optional<Integer> findByTaskId(int taskId);

    public List<Scene> findByStoryId(int id);
    public Page<Scene> findAllPaged(int page, int pageSize);
}
