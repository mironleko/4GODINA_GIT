package com.zavrsniRad.storytellingApp;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) {
        DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm:ss").withZone(ZoneId.systemDefault());

        System.out.println("Default Time Zone: " + dt.format(ZonedDateTime.now().toInstant()));
    }
}

