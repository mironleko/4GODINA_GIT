package com.zavrsniRad.storytellingApp.model;


public enum Authority {
    ADMIN, STUDENT;
}
