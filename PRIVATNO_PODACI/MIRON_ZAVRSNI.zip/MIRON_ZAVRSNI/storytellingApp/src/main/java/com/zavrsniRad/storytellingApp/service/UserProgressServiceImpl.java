package com.zavrsniRad.storytellingApp.service;

import com.zavrsniRad.storytellingApp.model.*;
import com.zavrsniRad.storytellingApp.repository.UserProgressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserProgressServiceImpl implements UserProgressService{
    @Autowired
    UserProgressRepository userProgressRepository;
    @Override
    public UserProgress save(UserProgress userProgress) {
        return userProgressRepository.save(userProgress);
    }

    @Override
    public Optional<UserProgress> findById(int id) {
        return userProgressRepository.findById(id);
    }

    @Override
    public List<UserProgress> findAll() {
        return userProgressRepository.findAll();
    }

    @Override
    public List<UserProgress> findByStudent(Student student) {
        return userProgressRepository.findByStudent(student);
    }
    @Override
    public List<UserProgress> getUserProgressByUsername(String username) {
        List<Object[]> results = userProgressRepository.findUserProgressByStudentUsername(username);

        List<UserProgress> userProgressList = new ArrayList<>();
        for (Object[] result : results) {
            UserProgress userProgress = new UserProgress();
            userProgress.setId((Integer) result[0]);
            userProgress.setStudent((Student) result[1]);
            userProgress.setStory((Story) result[2]);
            userProgress.setScene((Scene) result[3]);
            userProgress.setTask((Task) result[4]);
            userProgress.setCorrect((boolean) result[5]);
            userProgressList.add(userProgress);
        }

        return userProgressList;
    }
}
