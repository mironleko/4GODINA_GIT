package com.zavrsniRad.storytellingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StorytellingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
