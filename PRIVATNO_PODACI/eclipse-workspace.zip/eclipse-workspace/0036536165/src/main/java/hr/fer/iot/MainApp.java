package hr.fer.iot;

import org.eclipse.paho.client.mqttv3.MqttException;

import com.digi.xbee.api.XBeeDevice;
import com.digi.xbee.api.exceptions.XBeeException;

public class MainApp {
	/* Constants */
	
	// TODO Replace with the serial port where your receiver module is connected.
	private static final String PORT = "COM5";
	// TODO Replace with the baud rate of you receiver module.
	private static final int BAUD_RATE = 115200;

	/**
	 * Application main method.
	 * 
	 * @param args Command line arguments.
	 * @throws MqttException 
	 */
	public static void main(String[] args) throws MqttException {
		System.out.println(" +-----------------------------------------+");
		System.out.println(" |  XBee Java Library Receive Data Sample  |");
		System.out.println(" +-----------------------------------------+\n");
		
		XBeeDevice myDevice = new XBeeDevice(PORT, BAUD_RATE);
		
		try {
			myDevice.open();
		
			DataReceiveListener dataReceiveListener = new DataReceiveListener();
			dataReceiveListener.setDevice(myDevice);
			myDevice.addDataListener(dataReceiveListener);
			
			System.out.println("\n>> Waiting for data...");
			
		} catch (XBeeException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
}
