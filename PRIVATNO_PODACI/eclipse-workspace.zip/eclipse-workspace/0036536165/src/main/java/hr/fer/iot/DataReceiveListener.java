package hr.fer.iot;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;

import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import com.digi.xbee.api.RemoteXBeeDevice;
import com.digi.xbee.api.XBeeDevice;
import com.digi.xbee.api.exceptions.XBeeException;
import com.digi.xbee.api.listeners.IDataReceiveListener;
import com.digi.xbee.api.models.XBee64BitAddress;
import com.digi.xbee.api.models.XBeeMessage;
import com.digi.xbee.api.utils.HexUtils;

public class DataReceiveListener implements IDataReceiveListener {

	String temperatureTopicAddress = "device/WED/sensor/temperature";
	String humidityTopicAddress = "device/WED/sensor/humidity";
	String accelerationTopicAddress = "device/WED/sensor/acceleration";
	String topicAcctuationAddress = "device/WED";

	String brokerAddress = "tcp://192.168.1.101:1884";
	String clientId = "Gateway";

	private MqttClient mqttClient;
	private XBeeDevice myDevice;
	private MemoryPersistence persistence = new MemoryPersistence();
	
	public void setDevice(XBeeDevice xBeeDevice) throws MqttException {
		myDevice = xBeeDevice;
		mqttClient = new MqttClient(brokerAddress, clientId, persistence);
		MqttConnectOptions connOpts = new MqttConnectOptions();
		connOpts.setCleanSession(true);
		System.out.println("Connecting to broker: " + brokerAddress);
		mqttClient.connect(connOpts);
		System.out.println("Connected");
		mqttClient.publish("device/ESP/sensor/temperature", new MqttMessage("{movement:1,value:20}".getBytes()));
		mqttClient.publish("device/ESP/sensor/temperature", new MqttMessage("{movement:1,value:20}".getBytes()));
		mqttClient.publish("device/ESP/sensor/temperature", new MqttMessage("{movement:1,value:20}".getBytes()));

		mqttClient.setCallback(new MqttCallback() {

			public void connectionLost(Throwable cause) {
				System.out.println("connectionLost: " + cause.getMessage());
			}

			public void messageArrived(String topic, MqttMessage message) {
				System.out.println("Topic: " + topic);
				String content = new String(message.getPayload());
				System.out.println("Message content: " + content);
				RemoteXBeeDevice myRemoteXBeeDevice = new RemoteXBeeDevice(xBeeDevice,
						new XBee64BitAddress("0013A20040F8DBFC"));

				try {
					xBeeDevice.sendData(myRemoteXBeeDevice, content.getBytes());
				} catch (XBeeException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken token) {
				System.out.println("I delivered message -->" + token.isComplete());
			}

		});

		mqttClient.subscribe(topicAcctuationAddress);
		System.out.println("Subscribed to acc: " + topicAcctuationAddress);

	}

	@Override
	public void dataReceived(XBeeMessage xbeeMessage) {
		// TODO Auto-generated method stub
		System.out.format("From %s >> %s | %s%n", xbeeMessage.getDevice().get64BitAddress(),
				HexUtils.prettyHexString(HexUtils.byteArrayToHexString(xbeeMessage.getData())),
				new String(xbeeMessage.getData()));

		System.out.println(xbeeMessage.getData());

		String messageContent = new String(xbeeMessage.getData());

		String acceleration = getSensorValue(messageContent, "ACC");
		String temperature = getSensorValue(messageContent, "TC");
		String humidity = getSensorValue(messageContent, "HUM");

		try {
			mqttClient.publish(temperatureTopicAddress, new MqttMessage(temperature.getBytes()));
			mqttClient.publish(humidityTopicAddress, new MqttMessage(humidity.getBytes()));
			mqttClient.publish(accelerationTopicAddress, new MqttMessage(acceleration.getBytes()));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getSensorValue(String inputString, String sensorName) {
		System.out.println("String from input is -->" + inputString);
		int startIndex = inputString.indexOf(sensorName) + sensorName.length() + 1;
		int endIndex = inputString.indexOf("#", startIndex);
		String valueString = inputString.substring(startIndex, endIndex);
		System.out.println("getSensorValue:" + valueString);
		return valueString;
	}

}
