package test_folder;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Unesite datum rođenja (dd-MM-yyyy): ");
        String datumRodjenja = scanner.nextLine();
        LocalDate rodjen = LocalDate.parse(datumRodjenja, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        LocalDate sada = LocalDate.now();
        if (Period.between(rodjen, sada).getYears() >= 18) {
            System.out.println("Korisnik je punoljetan.");
        } else {
            System.out.println("Korisnik nije punoljetan.");
        }

        System.out.println("Unesite dva broja:");
        double prviBroj = scanner.nextDouble();
        double drugiBroj = scanner.nextDouble();
        scanner.nextLine();

        int operacija;
        do {
            System.out.println("Izaberite operaciju: 1 - Zbrajanje, 2 - Oduzimanje, 3 - Množenje, 4 - Dijeljenje");
            operacija = scanner.nextInt();
            switch (operacija) {
                case 1:
                    System.out.println("Rezultat zbrajanja: " + (prviBroj + drugiBroj));
                    break;
                case 2:
                    System.out.println("Rezultat oduzimanja: " + (prviBroj - drugiBroj));
                    break;
                case 3:
                    System.out.println("Rezultat množenja: " + (prviBroj * drugiBroj));
                    break;
                case 4:
                    if (drugiBroj == 0) {
                        System.out.println("Dijeljenje s nulom nije dozvoljeno.");
                    } else {
                        System.out.println("Rezultat dijeljenja: " + (prviBroj / drugiBroj));
                    }
                    break;
                default:
                    System.out.println("Nevažeći unos. Pokušajte ponovo.");
            }
        } while (operacija < 1 || operacija > 4);

        System.out.println("Unesite datum (dd-MM-yyyy): ");
        scanner.nextLine();
        String uneseniDatum = scanner.nextLine();
        LocalDate datum = LocalDate.parse(uneseniDatum, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        System.out.println("Uneseni datum: " + datum.getDayOfMonth() + " " + datum.getMonth() + " " + datum.getYear());
        System.out.println("Mjesec " + datum.getMonth() + " ima " + datum.lengthOfMonth() + " dana.");

        scanner.close();
    }
}
