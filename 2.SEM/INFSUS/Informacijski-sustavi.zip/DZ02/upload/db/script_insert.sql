INSERT INTO public."Administrator" (id, username, password) VALUES (1, 'admin', 'admin123');

INSERT INTO public."AdminZahtInter" (id_admin, id_zahtjev, id_intervencija) VALUES (1, 1, 1);
INSERT INTO public."AdminZahtInter" (id_admin, id_zahtjev, id_intervencija) VALUES (1, 2, 2);
INSERT INTO public."AdminZahtInter" (id_admin, id_zahtjev, id_intervencija) VALUES (1, 3, 3);

INSERT INTO public."ClanOdlikovanje" (id_clan, id_odlikovanje, "datumStjecanja") VALUES (98856733211, 1, '2016-07-28');
INSERT INTO public."ClanOdlikovanje" (id_clan, id_odlikovanje, "datumStjecanja") VALUES (98856733211, 4, '1992-04-10');
INSERT INTO public."ClanOdlikovanje" (id_clan, id_odlikovanje, "datumStjecanja") VALUES (98856733211, 5, '2002-04-10');
INSERT INTO public."ClanOdlikovanje" (id_clan, id_odlikovanje, "datumStjecanja") VALUES (98856733211, 6, '2012-04-10');
INSERT INTO public."ClanOdlikovanje" (id_clan, id_odlikovanje, "datumStjecanja") VALUES (57634299766, 3, '2019-07-16');

INSERT INTO public."ClanSpecijalnost" (id_specijalnost, id_clan, "datumStjecanja") VALUES (5, 34388876512, '2012-04-11');
INSERT INTO public."ClanSpecijalnost" (id_specijalnost, id_clan, "datumStjecanja") VALUES (7, 57634299766, '2007-11-03');
INSERT INTO public."ClanSpecijalnost" (id_specijalnost, id_clan, "datumStjecanja") VALUES (8, 98856733211, '2017-05-25');

INSERT INTO public."ClanVatrogasnogDrustva" (oib, ime, prezime, email, status, zvanje, username, password) VALUES (57634299766, 'Tomislav', 'Stipetić', 'tomislav.stipetic@gmail.com', 'operativni član', 'vatrogasni časnik', 'tomo', 'tomo123');
INSERT INTO public."ClanVatrogasnogDrustva" (oib, ime, prezime, email, status, zvanje, username, password) VALUES (34388876512, 'Branko', 'Josipović', 'branko.josipovic@gmail.com', 'pričuvni član', 'vatrogasni dočasnik', 'brankec', 'branko123');
INSERT INTO public."ClanVatrogasnogDrustva" (oib, ime, prezime, email, status, zvanje, username, password) VALUES (98856733211, 'Filip', 'Brekalo', 'filip.brekalo@gmail.com', 'vatrogasni veteran', 'vatrogasni dočasnik 1. klase', 'filip', 'filip123');

INSERT INTO public."Gradanin" (id, ime, prezime, kontakt) VALUES (1, 'Andrija', 'Tot', '099823164');
INSERT INTO public."Gradanin" (id, ime, prezime, kontakt) VALUES (2, 'David', 'Radić', 'david.radic@gmail.com');
INSERT INTO public."Gradanin" (id, ime, prezime, kontakt) VALUES (3, 'Jasminka', 'Stanić', '042765112');

INSERT INTO public."Intervencija" (id, naziv, opis, adresa) VALUES (1, 'Kontrolirano spaljivanje korova', 'Potrebna je kontrola prilikom spaljivanja korova uz prometnicu', 'Prigorska 19');
INSERT INTO public."Intervencija" (id, naziv, opis, adresa) VALUES (2, 'Rušenje stabla', 'Rušenje stabla pored stambenog objekta', 'Cestica 121');
INSERT INTO public."Intervencija" (id, naziv, opis, adresa) VALUES (3, 'Uklanjanje dimnjaka', 'Potrebno je ukloniti opasni dimnjak oštećen prilikom potresa', 'Ul. Vladimira Nazora 8');

INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (1, 57634299766);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (1, 34388876512);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (2, 57634299766);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (2, 98856733211);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (3, 57634299766);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (3, 34388876512);
INSERT INTO public."IntervencijaClanovi" (id_intervencija, id_clan) VALUES (3, 98856733211);

INSERT INTO public."Odlikovanje" (id, naziv) VALUES (1, 'Zlatna vatrogasna medalja');
INSERT INTO public."Odlikovanje" (id, naziv) VALUES (2, 'Sreberna vatrogasna medalja');
INSERT INTO public."Odlikovanje" (id, naziv) VALUES (3, 'Brončana vatrogasna medalja');
INSERT INTO public."Odlikovanje" (id, naziv) VALUES (4, 'Vatrogasna spomenica za 10 godina aktivnosti');
INSERT INTO public."Odlikovanje" (id, naziv) VALUES (5, 'Vatrogasna spomenica za 20 godina aktivnosti');
INSERT INTO public."Odlikovanje" (id, naziv) VALUES (6, 'Vatrogasna spomenica za 30 godina aktivnosti');

INSERT INTO public."Specijalnost" (id, naziv) VALUES (1, 'Vatrogasni sudac za odrasle');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (2, 'Vatrogasni sudac za pomladak i mladež');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (3, 'Voditelj vatrogasne mladeži i djece');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (4, 'Aparati za zaštitu dišnih organa');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (5, 'Strojar');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (6, 'Vozač vatrogasnog vozila');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (7, 'Rad s motornom pilom');
INSERT INTO public."Specijalnost" (id, naziv) VALUES (8, 'Spašavanje s visina i dubina');

INSERT INTO public."Zahtjev" (id, naziv, opis, adresa, id_gradanin, status) VALUES (1, 'Spaljivanje korova', 'Kontrolirano spaljivanje korova uz cestu', 'Prigorska 19', 1, false);
INSERT INTO public."Zahtjev" (id, naziv, opis, adresa, id_gradanin, status) VALUES (2, 'Rušenje stabla', 'Rušenje starog stabla u neposredno pored kuće', 'Cestica 121', 2, false);
INSERT INTO public."Zahtjev" (id, naziv, opis, adresa, id_gradanin, status) VALUES (3, 'Osiguravanje dimnjaka', 'Osiguravanje dimnjaka oštećenog od potresa', 'Ul. Vladimira Nazora 8', 3, true);