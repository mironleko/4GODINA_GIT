create sequence "Intervencija_id_intervencija_seq"
    as integer;

alter sequence "Intervencija_id_intervencija_seq" owner to etztpcugzndkxh;

create sequence table_name_id_seq
    as integer;

alter sequence table_name_id_seq owner to etztpcugzndkxh;

create table "Odlikovanje"
(
    id    serial
        constraint odlikovanje_pk
            primary key,
    naziv varchar not null
);

alter table "Odlikovanje"
    owner to etztpcugzndkxh;

create table "Specijalnost"
(
    id    serial
        constraint specijalnost_pk
            primary key,
    naziv varchar not null
);

alter table "Specijalnost"
    owner to etztpcugzndkxh;

create table "Intervencija"
(
    id     integer default nextval('"Intervencija_id_intervencija_seq"'::regclass) not null
        constraint intervencija_pk
            primary key,
    naziv  varchar,
    opis   varchar,
    adresa varchar
);

alter table "Intervencija"
    owner to etztpcugzndkxh;

alter sequence "Intervencija_id_intervencija_seq" owned by "Intervencija".id;

create table "Administrator"
(
    id       integer default nextval('table_name_id_seq'::regclass) not null
        constraint table_name_pk
            primary key,
    username varchar                                                not null,
    password varchar                                                not null
);

alter table "Administrator"
    owner to etztpcugzndkxh;

alter sequence table_name_id_seq owned by "Administrator".id;

create table "ClanVatrogasnogDrustva"
(
    oib      bigint  not null
        constraint clanvatrogasnogdrustva_pk
            primary key,
    ime      varchar,
    prezime  varchar,
    email    varchar,
    status   varchar,
    zvanje   varchar,
    username varchar not null,
    password varchar not null
);

alter table "ClanVatrogasnogDrustva"
    owner to etztpcugzndkxh;

create table "Gradanin"
(
    id      serial
        constraint gradanin_pk
            primary key,
    ime     varchar,
    prezime varchar,
    kontakt varchar
);

alter table "Gradanin"
    owner to etztpcugzndkxh;

create table "Zahtjev"
(
    id          serial
        constraint zahtjev_pk
            primary key,
    naziv       varchar,
    opis        varchar,
    adresa      varchar,
    id_gradanin integer not null
        constraint id_gradanin
            references "Gradanin",
    status      boolean not null
);

alter table "Zahtjev"
    owner to etztpcugzndkxh;

create table "AdminZahtInter"
(
    id_admin        integer not null
        constraint id_admin
            references "Administrator",
    id_zahtjev      integer not null
        constraint id_zahtjev
            references "Zahtjev",
    id_intervencija integer not null
        constraint id_intervencija
            references "Intervencija"
);

alter table "AdminZahtInter"
    owner to etztpcugzndkxh;

create table "IntervencijaClanovi"
(
    id_intervencija integer not null
        constraint id_intervencija
            references "Intervencija",
    id_clan         bigint  not null
        constraint id_clan
            references "ClanVatrogasnogDrustva"
);

alter table "IntervencijaClanovi"
    owner to etztpcugzndkxh;

create table "ClanSpecijalnost"
(
    id_specijalnost  integer not null
        constraint id_specijalnost
            references "Specijalnost",
    id_clan          bigint  not null
        constraint id_clan
            references "ClanVatrogasnogDrustva",
    "datumStjecanja" date
);

alter table "ClanSpecijalnost"
    owner to etztpcugzndkxh;

create table "ClanOdlikovanje"
(
    id_clan          bigint  not null
        constraint id_clan
            references "ClanVatrogasnogDrustva",
    id_odlikovanje   integer not null
        constraint id_odlikovanje
            references "Odlikovanje",
    "datumStjecanja" date
);

alter table "ClanOdlikovanje"
    owner to etztpcugzndkxh;


